
<h1>
This Is Your Number 
{{$details['phone']}}
</h1>
<h4>Varify your number</h4>
<h3>Click below link</h3>
<a href="{{URL::asset('log/'.$details['body']) }}">click here</a>



