<div class="col">
</div>
</div>
<!--//row-->
<a class="link-mask" href="#"></a>
</div>
<!--//item-->
<div class="item p-3">
    <div class="row gx-2 justify-content-between align-items-center">
        <div class="col-auto">
            <img class="profile-image" src="{{ URL::asset('assets/images/profiles/profile-2.png') }}" alt="">
        </div>
        <div class="col">
        </div>
        <!--//col-->
    </div>
    <!--//row-->
    <a class="link-mask" href="#"></a>
</div>
<!--//item-->
</div>
</div>
<!--//dropdown-menu-->
</div>
<!--//app-utility-item-->
<div class="app-utility-item">
</div>
<!--//app-utility-item-->
<div class="app-utility-item app-user-dropdown dropdown">
    <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button"
        aria-expanded="false">
        <img
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAABmJLR0QA/wD/AP+gvaeTAAAd5ElEQVR4nO2dd3hUVf7/X+dOSzKTZDLpjRYgIQmhdyJVQFRcCxZAbKxtddV114Yuuovud21r2bXXZaWIDUQQRHpJIJRgKCGBQEgvMymTMpmZe35/BEIigRQS1N+T1/PwPMy953zOZ+577r3nfM7nnEAXXXTRRRdddNFFF1100UUXXXTRRRdddNFFOxC/tAOdwT5blrlOGvqr0E1IAqWQBiFFLYhcVZJNjeun0ZGRNb+0n83x/40gO0sKRiDUmwRMA/q1UNwN7AGxCtwfj/SPyLkELraK37QgUkolyZo3UyCeBAa004wTxFcC9+sj/CN2dqR/7eE3K0hycd5QqeFdJIM7yqaULNbpeWioT1hJR9lsK785QaSUSrK1YD7IBYCmE5ooqquqfmjh1KvzFCGC3cKdZ45NT1q+HHcntHUOvylBUvLyvJx6uUwIcVVntZG67gfW/fsdgkJDagODAlynsk6o1mJrTU1N7ax1Bw9u6Kx2z/CbEWRbcbG3VnGtBTmqs9rY990akpd+zjOvPk+P3lENx1OTU3j+T09V2Surrlh76NDWzmoffiOCrJYZBovNuAbJhM5qo66mhtdmzuL1zz4grFvEOedTtiXxz8f/etxeWTXL1+z9Yl2dK0GiKjqtdku5veax9WlphzvCD21HGOlsLFbjG9A5YqhuN666Oo7uTKbfoIRmxQAYOnYker0+2NtXbLjn8T95DRo1jKqKSrat+3Hakg//O2FqbGyH3D2/+jsk2Zp7i5RicUvlXHUOvnjueSpKSpFuFaEITBYL3gH+WCLC6d4/ntDovmi02obya177N6k//IiUKgZPT0aPT+SRv80/bxubVq+T0f3jRGhkeJPjOzdskS8+taAoV2oi9+zZ47yY7/urvkOSCguDpXS/2dw5KSXWnFyKTpzAYbej8/TCEhHB4a3bz2vPYDQyYMrljLttNhvf/xBPl4slG1Zh8PRgzRcrUBTlgv6Mnz6l2R/wqImXCX//QGNtds4oYEsbvuI5/KrvkKTSvHeBuxsfqy4rY/uy5aSuXU9lSfuGCxqtFkWjsHTjajyNXh3hKs/c/2jV3h07Pqq11z626cSJ2vba+dUKklR0qg8azSFO38Vul4ut/1vM9iWfU1dz8WEoDy9P3l+xDP+ggIuyk3k4nY2r16HVati+fnOdtbi4pKqmbtT6gwez22PvwvfoL4hQNI/Q6JHqsFdRXlDYIWIA1FbXsO7rby/aTvLmbcz70wPc8dD9fPDtMv2se+8K8TF5rWyvvV+lINuKi72lYO6Zz1JVSU9KImNXSoe2k3nk6EXbmH3vXQhx9kFz/dxbFA8vz16Xx8UNbI+9S/JSl1LOBT4F3gPuSy7JHySEHCWF6A14IqQTVeQKhW0mP1tyhc05A4nxTP2f1m/kmxdebMYwF/XQVd0dHw0RikLPvlHSWljSB9jf1vqXRBAhxH9TCwq+rNa7HxBSHEOhh2x8JaUAAVJCpdWvWpFUyUanywryz2P44vwy+XhfnIHzkH0sS3ELd1576nbKI0tKGS2lrJONSAgOtvfyMv8f0KOF6l5SEHjmQ22VnT3fftcZbrJ3RzJv/9+rSFXtMJtrv/5WrbCVl5hj05PaU79Te1nbirPDtIp2KZB4MXZs+fm8fsttSLVzAq43/f42Rk8a1+SYt48PZouFMqsVS4A/J49nERgcjNniB0DuiWyqa6obyluLStixYUvt5jU/1DrrasZ9n5Z+oD2+tFsQKeXTwN9bUzbDbqOX0YwiBEcqS4k2WVCEQAIHK0qocl14cPvdv95k19fftNfVFvH288McFNTkWFifKAZOGs++Hzcy/IpprHjjLQZdPpEJs24C4IUbbtldXWE3nymv0SiVNTU16+rc8l/rDhwoaq8vnXKH7C4r7OV2u3cCQS0Wbo29b1ay6tXXO8JUs0y+ex6Jc25pWyWVoSMDw/Z0tC8X/VKXUn4LXAU8DriklPekVZSq8ZagoJbUbu0dkrUvtVGNi/8NKRoF1X32vWEOCW6zDaGwMLkk7z2Nf+iqoUJcVPyqMRctiBDi6safk0ryAhE8sct6np5RO3BUV51prbn2kVK22paXh4GoHsH8dOTsQNocGtJmnyRMQzDNac3P3lmat3CkJfRDIcRF9w46tJeVXFbQE8HDHhotwy2hjLCEYtF7XLRdT++m3VMhBP2iwrl71kSunHD+3AZPD32Tz95GD556YAaJw6KbHDcHt/0OafAFugl4L9mav3lHyanwlmtcmA4dh6hu9UEBHrVuFx15hzR+pPj5Gnnu4evxM5vIzStl8Tdno7saReBWJUYvA1dNGkSQxYc3P10HQLcwf26aPoKIEAshgb5oNQout4pGp8V0uud0kYxVhCZlt7Xg8mGWkLT2GukwQVbLDIOwcltH2WtMYI/uDf8fM6QPZl8j/3jtK2rq6nA43XQL8cfLoKXG5WZgbHeumjQYo6eex55fjIdeR1REEN2CzWxLOoy9ykHiyBji+kaQejgbc3AwooWwexsIUVV1w+6ywpHDzMHH22OgwwTxKzGNQpGWjrLXmLDoaDR6D4wRfSByIIsPSvwSr8HodBGh12LxEPQ0S3r7OLH4eDbUm3v7tRyv0lNkl5S7699AmVooPuLGv98wtCdt+IWFdaivUhDodqtfp0g5tD0v+4sWZHxcnMmgVWYunT//TwZPL3xDg+kzcgTd+sdfrGmgfq7b5G9B72PGL34Uek+FK3oqeGgEp7JLeed/G7jymnEU1QSzt0DHPUNACNia7eZwiY7EbgJd4VF2pxzhT/fNQCgK6aWSPXn+6M2BeJhMOB0OdAZDh/hbj0xw2woeBl5qa812C7IxK8tj15df/G3PqpUP9+obpR0+ZoQw+1vIOZHNmpdexRQUyIwnHsM7wL9d9l11dax49jlkRSkupxONswqtdPK7aE+0Sn1vq29UMAZFJXN/GvfcHsa/d7l4Z48LvQby7ZJHR+pQpAtduB9ffllAXl4RfXuFMjhUcLhEpai2krKjh1j/9OM4FB1XPLMAg8nU3kvSBCnlX5NKc5a0NU21XYLstOZenbE9+f19q1YGP/mPBSQMG9Lk/C1338bidz/mkz8+wrx3/oNnO4J4h37cyOBwT6bMnMKpfCuvvP8doR4uNI1C3es3HaC4tILJ4xIA6GGG7mZBH4vCB3vdeOrA4ZC8/ck6jF4GwoLPvrx1GoG3xsn4YfFMHz+AbSlHyVz5FXGz5p7jSzsxSaHcB5x/kr4Z2ixIUkneP6rLKh5f9fKr4ulXniduYMI5ZRRFw5z75lFVWcUPb73DjCf+gtPhICMpmeITJ9FodYRF96XHoAEomvMkH2q0DQkJZWVlGAw6egR6YK0F/9OviUnj+tM/rhvBgfURDI0iCDZq8NCCt75eOINBx9+euAlVSkzGRl1wCb7enngZNNjtp8c5mo6NtQrJbCnlM20Zn7TJg2Rr3kIET6R+v1bEDxrQrBiNufX+eRzeso2Ulat44+Y5HF61mgCh4ltXy46PPuad2+eRc6j5dKaIuH5k5NkA0Gq1eBj0DAjTsb/g7HcTQjSIIYHSGgg8PYsSZISiqvoBo9HLgHcjMYqqJD4eYNBrMRo9cKlu0o/nEZQwqC2XozV032XLH9OWCq2+Q3aU5k2rq3U8pTMYyEk7yJXTL2+xjpfJSPSAeLZ9uojn3niR6PjYJud3btjCa08+zS3/fIHwmKaDNb+wUHJy6wXx0BuQqptwb0FqgeRkmaS7+eyjS5Ww7ribISGiYSyf2EPDN0fcXBOtNNwtANUu2HRC5apoDalCoFE0aDUasnJLGds3prWXo9WokmFAq/O1WhRkalycxcvX6/UXr7h6tsvlEubgYGqrqvCbe1OrGrhl3m34WfwI79HtnHOjJl6G2+Xi43++xD0fvtdkPCCEQG82YyuvQqfXcWZC64reCgeKVLJOqihCUOuS1LkgLlChp9/ZC2/SwTXRCjtOqagqeJ0WRSNgRrSCh7a+DbeUILRoPLzO//i8CJSW16o04YKCzBwV4elSPbaOn3p5n7n3/16YfL05nHqQfy14AVddXasaiB984WUbY6dM5LP3P+FU2iG6JTTtKkeNGU1KZib9wswNv3whYEBw65603nrB1KjzX2RFCNyqysH0HHqPGN4qm21FQnTLpc5yQUHKK31uGTQstvsD8/+iO3MsblACH6xc2lBm785kjqQepP+wQfQf0r5ncPzggeRnZp4jyOArr2DxXx4nIyOnSSLB+SgqLiev0AoIFEXQv1+3C9cTsCnpMNUYuPGVV5otMsgchF7RkF5pxV/viRBQWldLX1PL4Ra3lKSWFelaLNiIJoI8C0pS/7i5Jm/TA45aR1+3262fet3V5x0xff7Bf+nRN4pZ997ZljYbkKrKoQNp2CvKObpnP+Ex0UTEnr3DtXoDs156kYPrN5C3fOkFLNUTFOhLUKAvblWiUVoWUNFoCB40ihFzbz3vwHBf2dm5pjKno+H/ya2M1UlEVculztIgyPi4OFOq0WtT7x6R0bPvvdMUFRNNncNBcHjzoenck6fw8fNl+GVt6kQ0YCuxsuzDTxl+2WhuunMu675ZxVfP/p0B06cx7vazYwGtXk/CtMvZ/9258+pSSirttfh4ezY53pwY5RVV+PoYmxxzag2MuuP2hu51a4jw9Cbc04RLqmRVldOnmTvlZHUFBbWndZBqmxLJGjzx9/H6evSkCXEPLXjC43y3+ZEDB9mydj2eRi/SDxzi/qcebUtbTfhq0RLufPh+9Kd/mXf/5SFuvGsuT9z9ED4hwQyaNrWhrFA0+ER041BeJbFhZweZQghsZXYys/Lx9/MmIswfTaOxRKW9hhPZRbhVlejeTSPj6cfz0fhY2iQGQE5NJTk1lQ2fW7pThBDpbbEvAKb1jxnl5x/4wyfff2XU/sxBqaqkbE8i9+QpCnLzuPfxRwCwV9oxGr3aHSktKSwiIPjcGd70tEP8/dH5PLhkUZNeT3lBIV/8dQEL7pyIp+Hci5hfaCPrZBEOhxOJRCDw9/emb69QPH42L1JTW8fTb6zgxpdfwRJ+4eBilMlMgN7zgmUAVCSZ9jL6mPxQpSTDbiPGuyHWWgV0F0KUtmRHC6DVGqZPve5qj5+LUedw8OG//kPilElMnjG9SXa4yfviYj7NiQEQHR+L3qDHmptLQLezXWXfkGDG3n4bb65YyZ9nDkERTX8IocF+hAa3/KJVpcq7X+xg7F13tSgGwDF7Gccoa7HcGRrPAyVb852q1h0y2jfS2tr6CoDBw9A3OCz0nP7h919+yw23zyF+8ABMPt54mYznWugEQiPCseUVnHM8evQouo9J5LUvU6hzudpsV5Uqby3dTtCoccRPntwRrl4Qgfy6LWLAaUHqah1Zhbn55yQ9xQ3uT2BIhySOtImi/AJM/s1HiQdfNR3/hCHc99dFbEw6jCqbhols5XZyC23n1LNVVPHMm6sInTSNYTdc3yl+/xwJa9taRwBMiY0d4R9o+fGT778yanVt6jZ3OEcOHGThY8/wxyWLLvh+OrJ9O8sXLESvFSQOiyYy1IJWUfhizS7sNXXM+d1oLD4mKuzVbEvJIONkEVf9+RESprYc8ulASoSqjhkRGNHqrO6G7tR1I4d+N/yyxImPLpzvoSidsfy7ZUoKi3h83gMkzruLuPGXtVh++5LPSfl8GTZrGRdKPPExezP0husZN/fWDvS21RyqsYQOmCBEq56xDW9xa2XNTbs2b/vuDzfcNviGO2abekb3wdOr5d7FGfwDA9AbDEhVpSCvbQkOtlIrqbv2snLx54yefUurxID6HuCo8UMYHuLm9f/twlpe3SRzy9to4P6bhnKo0ovqX+hHBsR62gruBt5qTeGfDzjEtPiYa03evvNUKfupbrWJIgYvT5NWr2/2zT7j/rsZOGk8uRnH+Gj+AqS79SlKJosfIdF9GXrN1U0SGlpi7VvvEqmzM2dE/eh89ZYMlq5JQ1VVZk6L5+pxfdBpNSxJqSCryoNpD97fatsdTM4IS2g3IUSLCWRtSgOUUopka/5rwB/b7VoHUV1WxucLFjJ9TA+mxZyd66hxuHC5Vby9zo49fsyo4+tNR7n578/iZTY3Z67TUaQYPjwgdHdL5do0TBVCSCnlw8m2gnSkfBG4NP3g09RW2Tm8dTtpP24k9+Ahhowdwvg+ntRPT9XT3KAxsZeBvRn+vD77NiLj40iYPImYxDHoPZom8UnVzU8/buKn9RvxDQrgqkcfbnK+NCeXRX9+nJjEsQybcRX+kc2vaW8OFTkZaFGQdifKbivODtMI3UNCyNnARWfsnQ9XnYP07Un8tH4DJ/ftZ8CoYYxMTOTU0cOIukpCvFV6BQj8vD3wNurR684K4lYlioAK6c32g+WMuuJKXDof/vvWO+xN2kWPIUMYcPlkooYNobqigo/+8Aglp7LxCwynrCSPK/74AMOvvRqhaLDl5rH0mWepKKhf+VtTbWfy7+9k7OybW/dFpHxrZED4H1oq1iHZ77uLc6PdGiVKSIxuZKWCmAmyfSHg0+QcOsz2JZ+T/dMB4gcmMHP278jLLaakyEq/ISMJ71G/7qekoIDsY8epKLNRWV5GYW4ebpebgJBgtDo9Y6dOwWg0UltTg9nfn7SU3WgUJ2PGj+XksUxWfbOWPTuT6T95ElsXLyN20OUMnzSL7Ws+Jm3XGjyMRjxM3pQXFWL0sXDFLU9iDgjlg+fnMu3Bexl5w3Wt/UpfjvQPu6GlQh2SKDcsMDwdaAiiJVnzFSTtEsRd52TNm/+hMvskI8YM48mnHib3VC5VNXUMSRxLanIK275fxfV33YtWpyUgJISAkPqIdLnVykfvfIKUGm6+5hp8LWfz9jy8vKipqiI9dR93/+VBAHpE9+OBx/shVTdHDh5i8yefoWh0CCEYO/1O+g4cR07mfpx1tZhHR9ArdiQ6nQFVrd8poi1IsLemXKcsaRNu2a4FK6rbzbK/Pkd0t1Buvft2plx3LQf2HCCyV080Og0ZBw8zZMxIxl4+gXVfLW9S1+Vy8em7HxI2cjqRY67k03c/wuVsmjj43dIl3HjXnHP9VTSUFVtxOh2Eda+fj6lzOpE6C5YeYwjsPRFP/35UVTuREhRFIax7DHtXrWn1zKkixbmxoGbolM75nU8/XCtU5THa+EjcsugzQn2N3DD7JqylVspKrfQb0J8925OI6R9PdXUVxQWFRPbsQbnNhr2yCv/TmevvvfQKPvHjMBh9EIoGnTmE7V8tYnhi/Wq6w/v2ERjsR3R8/QXPP5WLtaQUt8vNptXr+PfClwjvNYD4UTM4eaqIYyfyyMs+RuHJNEryM7FZiymvAqutEr1BR2hkFPs3r+B4yl4s4eEgJdlpaed90UvBfz988ZW9LV2DTltjmFySlykFUS2XrKe6rJx37vw9i1YtYeuG7QwZPYLj6RlodFrCIiM4uC+VgSOGkXnoMINHjwTgvRff5MpZc9i9ZTP5OaeotsTiHVTfvyjLPUFA3UksQcEMHXsZq5ct5u4/P9DQ3tP3PsLenclA/bxK7/5jGTHlTjKzCrEVHsNhO0ZEr35E9opFr/eg3FrI8SN78QwZgsPhJCIsAOEoZNPKt6i0FTfYvf31l+k56NypbFWRg0f7he9r6Tp0miA7S/I+E4JZrS2fsmIVgcJBdGwcIeHhpO3Zx9Cxo0j/6RCKRhAV05e9O3bXZ6q4XRhNJmwlVt558XXiBg9g+g0zmP/gUwQMnYaqqpQf+JGFry9k9fIVpO7ezwPzH8HXrz48f/xoJg/MnMvwiTfjFxSJf3B3TL5BpB3OovDkASw+WoaMbX7TOpfTydov38av5wR6R0USYPGhKDeDupoqUrYsxyfUj1tf+b+f1ZJJI/3DW7XxWqft5CAU2aZ9KzKSkxmQEI2jupaC3DzihwwiefM2+sRFo1E05Jw4RfyQgSRt3NIQ0vELsHDHQ/cw4+brOHYkE7vw4PiJbE5k52BzCE5knuSqm65j3iP3NYgBsOPHTQhFISpuND1jhuPjF0x+YSm2kny8Dc4GMWqrK0nfv5F9274m78RBALQ6HeOmz8FdlUv2qSJUVRISGU23voPxC4gka+9eauw/n0ZXms+gaIZOE8Tl1n8HtHpXnKKsE5zIPEXMwP44as6IMpCUbUn0ietHtd1ORVkZvWKiaRz8DDk9ybRh7Ubc5rMTWqp/DzZ8X79FYnB4aJO24gcNICgkhG8/fY7a6gpAUlBkpboojWHjflfvT24mS//9EJtXvsuBXatY+cmzbPj6DaSUmHwsxPYfTI29lBJrOQD7tn1D+v6NDL/huibTyCA+Hukf+kVrr0On7eQwNjCwMsma9zmSVmUvR8TF8t6r7/Luq2+jKApSgqq6UBSFt//xKopGwe1yo9E23w9xOp3oPZsGDr6rqWLd8uXNlpdSpaaqhgNJq4kb+Tvq6px4GT3RaHVIKVn/xb/Q6rU8tHQ5XmZfDm7YxOd/e56wHv2JGTQBbx8T9qIjlIdGEOBnYu/Wrxhx/bVM+8O9jVtJUqvdLQ4GG9OpW2uoKC8rqLfSinfV9U8/ec6x2io7HsaOWR7QHMueeY6C7CP0GezE5ajE7Fc/GVdhzafCVsQdb7yCl9kXgLiJ4+n57SpOZe4jZtAE9AYvFOGmttaJtfgUTkcNCZMnNja/3alxXZ0Y2b1NWSeduhvQaEvITxLaveK/M8WA+uXRSImUoDP40L1f/XtXnH4kul1NJ1GlW6VxuFYCikKTZDwhcUjBC94W28REc/dzpy5b8qntX6NtqAqPANUtFrzE1FbaObZ7D0FhUfVZKUJQUlS/X4y3OQhLcHfWvf0etvx8VLeblBWrOJl6gJ4xwwBw1FajSg0Ggx5LYAR6g5dc/95HSW7cUaMsYfPjRFzrRow/45LsKJdUmv8oyJcvRVutIf9oBt/882VsOfnceN8reHn7s/+nY+Snr2fqtXeg0eopLTzJ98tepNJahEanQ3W5iB06RSZeOU8A7Nn+HXaXmZjYWIID/UjduYqdaz9FCPmm3innr0xPr2zJj+a4JIJIKUWSNf9LAddeivYaNw2kAf0bH9z86SI2fPgJ1857geCIPgDkFVg5lpGOWnGUcVfWLyZ21tWSc/wA1fYygiP6EhBSH9Csc9Tyw4pPCe47gcEJvRvSozZ+8x/SUze73IbagPV7jpe3x+FLsqOcEEIKDLcjaDF00JFIycPeFttQEB81Ph43YRxCCAqyD5N/8hC11RWEBvthDgihTrGwbe1nqKqKTu9Bz5jhxA2d0iCGrTSfo5lZ+PcaS89uIQgBhTkZnMrcT2FOhlMg1rZXDLjEm2AmV+T4S6fyI+3/0xKtRUWKP44MCP1PQ9uleY9IWAh4ASyZv4AjW7cBIISGfkMmMnzyHI4eK8BadJLKgv2ER/ale+84tHoPrCX5nMw4QLVDYuk2jO6RoQhHEeu/fMNlLy/Wnm1YHfvDwfTz71XbApd8V9J9tiyzQzX8D7iyk5ooQ8rbRwaEr/j5iRRrXjcX8jGkuNWWm+djyy/AZDGTviOZTZ8sIjJqAJfP/DOncosoLLbhqLJRXZ6P6q5D5+GLlzkCo8lIz27BuKpL+fL9J9zS7f5Jdat/kTr1mFRFnx/Sjqy7GOd/kW1ipZRKUmn+Uwo8LQUdtkBcSDYrWs2dLe2isFpmGCwlptEoMkFIEQqw4aMPwjd9unjOVXOfIaJXAi6Xm/LKKqqra5FSotNp8TZ5YTLWh21Wf/YPNedYapZWb0j4ds+eDutF/iI7W59elbpwR0neF0LKlzrgz09kCSmeHe4fsqg1mR3TRR8HsPH0vwam9e8/JefYgaCIXglotRp01GA7lYKjxo5fYARB/sMayuadSJNu1fXBmj1pHdql/0W3Gh8dEHYEuDq5OG+oVMR9IG8EWjsaVIVkK4p8V+MX9kVH7FklBC7H6XUd+7evIHn9Z1IiXIqiKVPdzgCTT4B7+pwntSbfAKSqdsrT5Ve1s/XGrCwPTx99IojLJMQJQTckZ8K0tUAOcEQKdjl1Yt1l3qHFFzDXJmaOivC0281bVdU9xNs3wFlZXqID/unjU/nc8p05NdMSoqORus/1Bo84l8slVZdTlaiPrU073KFb3f2qBPk1MDUubhowSwipfJ92qMl877SYmB5olWVI+a3bpX70Q3p6u7aC7aKLLrrooosuuuiiiy666KKLLrrooosuuuiiiy4uKf8PbgV1lpE7G9UAAAAASUVORK5CYII=" />
    </a>
    <ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
        <li><a class="dropdown-item" href=<?php  echo "log/".session('LoggedUser'); ?>>Account</a></li>
        <li><a class="dropdown-item" href="#">Settings</a></li>
        <li><a class="dropdown-item" href="{{ route('auth.logout') }}">Logout</a></li>
    </ul>
</div>
</div>
</div>
<!--//app-header-inner-->
<style>
    .submenu-link:hover {
        text-decoration: none !important;
    }
</style>
<div id="app-sidepanel" class="app-sidepanel">
    <div id="sidepanel-drop" class="sidepanel-drop"></div>
    <div class="sidepanel-inner d-flex flex-column">
        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
        <div class="app-branding">
            <a class="app-logo" href="#">
                <img class="logo-icon me-2" style="border-radius: 30px;"
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAJkElEQVR4nO2bW2xcxRnHf3PO2T327trr2N548d3kHidxIAgQlyRQmpSE1BGOKX2g3CpFrZCQaNU3KKWvVSUqKpWoXCqoQE1NwKFQUqAGAoWXVhjIxYRg5+I48W3Xu+u9nXOmD5t1vPZ615fNbtLm/7TnzOib//f3N9+Z+WYMV1BYxDvbDsZfb7ujUOOLQg2cRLyzTZ7/+TEWT9p2drybz/GVfA6WBddKhavzPaiW7wFnwBHLUu7Rd+79It8DFzwCBLyo6Y7rCuE8FDACfnfnnaWaXX/m2eetIhEfsQOhQvAoSBJ8prX1BoH6Msil51/1Caz7fvrGGx/lm0teBfhLe7s6FDN+LuHXgG1KsynhN7Yqz+O79+yJ54tTVgGMzl2tEvn6fAeIjUMkKBEC86tv6O3+Si4BkFIyMB7AklDtKp0gsnKFOH7tCllvWULTXaA75/83ElK2aq2vdWbsk6lR7t/hMKX9SwlNcx1cSgj7JUYUUBl+6z20saB0A8RMg5OBMaKmAYBd1agrKUVXEynJ6RTBbbcTVCVezQ5FboEyj3Qt4YQtojSLe/YGZ+qT0axh2Z+cj/NmTBIalpgxKc/65NevviErks77ohG+8Y1gSEtu+cHOse33tQcMacnj/lFGIxEAQiHp2rtfek8P0WMayPFhiRGbKwsQUG8Uy8ez9EmPaGdbsyL4D3LaXM2IaEgSDYLQCH/0mRg5dcaqAbCQnAuFGImMU1pSEr37kQdVp7tUAxgPhIx9v3/e8Pn8RW69KGVKeKsYuO1GUSJNnHaHoKhkLmwAMKSwrrPv2Pd5usa0AkiJMPa3vQ9snu0olpkIeTMOUZOT+9+RXsNKiJcM+ZhpsGr9Ov/mXXe5hTYl+KTFv/72T/+/P/7UbVfUlCmhKJjbvyP6nDpXqzZwuAVCnS0zAHlQ2/HaRiGQU1vSChDrvPthgfjjbM3HoxDxSywwDx+/kOggEfJngmNoNtXa/sC94ZolTc6EUwqLvV6EIjh3ZgDTNAHoP94bfvOFV3UjbihXuUop04smxlm5Qhxfv0zWCyG0IjfY9NknSCl52N7a8XxWAeTf28uNmHUE8GS3CpEgxMYl/nEr8GznsKveVSkgNeQrPJXhnT+5Xy9yFCsAenERV1XXYNftCQHjcc6cOk0kHAYgFolanXteCp/tH3BOnRLfBofkQ98rH6sqU932ItBLBWJ2OoxomrJSbNs7mFEAY3/bc1LyUDZrlgHjfomVSOQ88aezADSUlqEqgtOBADHL5Prbbh3d8N2Ni5IkF5WXE+w/xxcHPmCo9xQAnqY61m7ZREmtl+HBIUAipeTzrk/8nxzoctsVlZqSEkwp6fP7AHjq/ioAFC0xJZRZrGkFPKd9v+PHMwoQ399+C9L6MJ0wSUgTYhGIhSRy0oxKCpBEkV03W3ffZ1TWeHUAVVPxVlfz5dtddH/ypXnUfWvIXlZRApK4bySwPPSpY/2NK7XmrZsZ6O/HMBLKjgwMxvb94UUlEommuJgUAEAIsDvBXpQ1N0iEuN22469d0wSQL2wu8lExYhmyOKOJGTBZgNqm+uD2h37o1Gw2AeBwOvHWVHOq+wj/eOlN80N1k2KYhmjfuQ6Ava93o6mavNX80Nr6wF1qbfNKBvr7CQUTn2/DMOV7f+7wHzvcU5ZOgLlAUYmWxSvLxe494zBpHRDQyjvm63wSbqdq/azdE2jd/SOXZrMJIQQVHg+1DXVomkb3gS605ZtOrFjSIpqXbaCstAL1fKY3TEP0uG8e736nC1VTqamvw1NVhRACTVPF1vvvKfvFvZ5QeYlqLYSjZaIHHEN7k88KwPgru26KR+S2hRjeuMYVeKy9QrgdSgmAzWajrrGBCk8lyUAb6j3FqLZ6sapqqJqGrhezfk0DbTtaqK8t42xQdQ1+e3LC5qKKcuobG7HriaWIS1ecj7ZViI1rXIGFcI1H5LbxV3bdBOe3w/GY7FjovuiODc6S5Fe2tMzNYq8XJcv69cjRIJoqWOypAPrS9tGLi6hvuppzAwMACCnEHRucc18OpUAQj8oO4CoN4OXXLO9CzMUti69Hhyaen26rTtvP01SHWztyuid+zXKAc4NR3v8gimmanDjlo9pN0FNVP805RVHwVlfz6KQ8s3xRBZoyp9XQFEgv5KAiFLcszgTHZtV33dZNRA+/21SshvypXCSaqskVvo8dLVtmt/jsDwUwLHPOfKdCAzg0fG7BhmaDhvVrOPdNn806+LTLsXZrT59srgYot7oHq4yD9ddsalHrW1bPylYwFqMnNrxgTikT/9DBt6etleeD5atXZWzv+/wrut/pYvB4IuF5ltTTsmUz2ZzvOXQ4F/RYfcudE34XpCbY0NJMQ0tzIYaehoJXhQuNlAgocTnnZcQ0TcbDkZwQmi0cjmLU+ZSJpiDjFCgf3PeFPXxibfL5qLgBgBXys4k+0eLG7lFP67oFM5kjVEXJCb+MEk42PhP0cG/enU8iF/wyRkCn8mja90fFjSnP12djcZGQC34ZBaisWQ6Ajo1lyy4s0Hr7wpQkynmMDseAgpxq5YRf1iySzfjSpfNLnLnCQvlljABd2Fi29BJ2Pgf8MkbApew85IbfrD6kl6Lzk7EQflkF+F92HrII0Ht8bHTC+Eg8rXHfaLgg5/qQG34Zk+Bi69Aizu84i4HxY9P72KFgIZELfv/3m6ErAhSaQKFxRYBCEyg08lIP8Hc8lvZ9ryuxa2sMfpq23d3220xmc8IvowC5qge4V144x7MMk/BAACMYBaCo0om7tiptWzZclvUARVMp9pYQODbdyUxtF4tfQeoBijbziU6mtovB70o9IKPxHNUDjkbWTHsXcTXh02tRTTtEprcBtGSxmwt+GQXIVT3ghD31vE9DoXytDr4xTCBSdi0+XxxdPx+QZRCLZr8GkAt+szoZWmjYO0orJn5PDtne83eEEBXUNVygEvTHWbXKAbH+Wdm/bOoBU+crgN8Xn7APCecbGh2ztnnZ1APSOe/zxbHrFyjM2fnLpR4wNVn1fH0Su73ywpwHzg6cYfWq+mymcs4vL3uByc4DxGLTw95KXjjMM/K+GertC6NpF+5fx6IWDY0O7PY53cnOGVIEEHDwYg6WTFiexYkrSbGohbss4fjyZXUpfXuOzXjFf4EQKf+WIwC2PPVgTm6GJPHWI79Mefbbq1OyNSTCXjICQGNjbUr/nmNBYjLGzQ2pK6Rtz/wqlzQ58MQLIi9ToC+N8zNl+6Tz+UJeBHBdos5DnpPgpeb8FQD/BZRleSkwmTTnAAAAAElFTkSuQmCC" />
                <span class="logo-text">Proskool</span></a>
        </div>
        <!--//app-branding-->
        <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
            <ul class="app-menu list-unstyled accordion" id="menu-accordion">


                <?php if(session('Role') !=0){ ?>

                <li class="nav-item has-submenu">
                    <a class="nav-link submenu-toggle
                    <?php if(Request::is('board') || Request::is('medium') || Request::is('period')){ ?>
                        active
                        collapsed"
                        href="#" data-bs-toggle="collapse" data-bs-target="#submenu-1" aria-expanded="true"
                        aria-controls="submenu-1">
                        <?php }else{ ?>
                        collapse collapsed"
                        href="#" data-bs-toggle="collapse"
                        data-bs-target="#submenu-1" aria-expanded="false" aria-controls="submenu-1">
                        <?php } ?>
                        <span class="nav-icon">
                            <img width="25px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAE8UlEQVR4nO3ae+zVYxzA8VcllZ+UilrktinNJbksa9gSuZRlc2uiNSuiZmTLZYYNscSQFGKuc0la1BbZtMJKobSRGRsbjQiZyybyx+d7/E7tdy6/7/mec/rpvLez8332fb6f5/l+vp/n83yez/PQoEGDBg0a7La0q2Pb++Dq5PoRbK1HJ9rXo9GEZ/A9NuOpOvajbqwucF1T6mkBuwSlfEBPzMDRslfWEdjYwnVWbMd63IAf0wqZhYvU11lWwsV4qFiFUl+1M7YIbbZFtoh3KEipL3sAHhdD4LuMOlUremMDJuDbSgT1xcIselRjFoq+F2WPGnQka05BnyL3l+HncoWlUUAvTJXNrLAdD+ObVjxzIA4qcr+LKitgAPpjbopnd2YcBmmdAk7AMUXuv4ZN5QpLOwS+xlspn83n5BTP3KK4Z/+pNcLaog/4I/llQhoF/IgzsDaD9jvh9QzkpCaNAjaKuOB/QRoFtMPByp8FtuKHFO3kcxh6CKtrj30TuX9VKDeVAvrgHuUrYD3uStEO4exmYWDS3ssYLyK7HmK6ewBLU8pPpYBNGJNX3kuM5UL8maINwtLmi5ebiLeFh1+E25I6AzAdozEFf7e2kSxmgek4ssj9Nbg5hdxL8AVmJ+V3xAsO06yAz3A+7sPdmJainZLUay2wDPvnlYdjJlaIfGI+7YSl5H+Imq0FHsNxRe6vxHUp5HYTOcMcf4h1wBvCChbl3duO+3E5rm9NI1ko4IoMZLREOxH2XiDijo24VSjiQjsqAN6VYqilUUBuSHRI8WyO73FOiTprMBkLRFpuCEYIK1jZQv3fxEIoc+qZD5gg1hzvial3uMLrgD5Ykleumg/oK/L4leQJfxGmXYoRuFeM+1KMFo4zc+ppAUPES5UKurrjA+E4c1TVAir1AZtxdhn1VmMVnhDDoaVAp5sImG4VlpU5u0JOcBo+xKU4FB2T/yniy49s4Zm6WcA4fJJCbjFm4EWxDhgrTP4rERQNU+WN1V3BAtJQlgXs9nuD5QyBDmgSa/K2RJMyHHWpuXyoWI19nkWP6sDhIpp8L62AF8TObVtloHiHgpQaAusxCYuz6lGNORfrilUoNQTai8TEURV2pDvO03wUZmQiO5cRHiXm9txsM1ZEgPnL4TRsEBbwT4VyKmae5ti/P77E83n3nxV+JrfjcxZeqkXHajENnoaueCVpb66W1+1T8aiwhKX4XaS72jRNYl3fOylfgzuEd97ZAvrjpuRHxPhrRfa3zTJbxO9wiFBGZ4UVsIdIfuZye6PwdDU7WM0hMBT98JxwtnNwreJp8m3i8OQcEcQsxp5ird+m6CLMt19SnigyujkKWUCO2zUnUnvhIzGTZE61Tn/NFEnMeeKc0Qo7blt3wsdiuiMUMNiO1tETp4u9gTFi1XdllfqbKUPwpmblvopTd6pTygLgWBEL5OQsECmyTMnaB3QS5/KuErn6y8TpjxUpZK0Tw2hSUp4sEqN7V97N6nGnyNLAfsLrd22hXjkWQCj0fc0r0fF4MJOeVoFBWK7ZqubjzAJ1y1UAnCSywrmhsETsDWRCVkdkOuJJ4fwG40SRpiqWzu6B45PrnkXqrcKnIlJcLhzr3OTZtDvP/5HVLNBdnAHIKfRPsYNb6LhaV7Gb2zEpb8ON+LVA/SYRQTYl5X+SckUnQBs0aNCgQYPdnH8BtkPnN5mgDCQAAAAASUVORK5CYII=">
                        </span>
                        <span class="nav-link-text">Class Management</span>
                        <span class="submenu-arrow">
                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down"
                                fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z">
                                </path>
                            </svg>
                        </span>
                        <!--//submenu-arrow-->
                       </a>
                       <!--//nav-link-->
                      <div id="submenu-1" data-bs-parent="#menu-accordion"
                        class="
                       <?php if(Request::is('board') || Request::is('medium') || Request::is('period') || Request::is('period')){ ?>
                        collapse show
                       <?php }else{ ?>
                       collapse
                        <?php  } ?>
                           "
                        style="">
                          <ul class="submenu-list list-unstyled">
                             <li class="submenu-item">
                                <a class="submenu-link {{ Request::is('board') ? 'active' : '' }}"
                                    href="{{ route('board.index') }}">
                                    <img width="25px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAE8UlEQVR4nO3ae+zVYxzA8VcllZ+UilrktinNJbksa9gSuZRlc2uiNSuiZmTLZYYNscSQFGKuc0la1BbZtMJKobSRGRsbjQiZyybyx+d7/E7tdy6/7/mec/rpvLez8332fb6f5/l+vp/n83yez/PQoEGDBg0a7La0q2Pb++Dq5PoRbK1HJ9rXo9GEZ/A9NuOpOvajbqwucF1T6mkBuwSlfEBPzMDRslfWEdjYwnVWbMd63IAf0wqZhYvU11lWwsV4qFiFUl+1M7YIbbZFtoh3KEipL3sAHhdD4LuMOlUremMDJuDbSgT1xcIselRjFoq+F2WPGnQka05BnyL3l+HncoWlUUAvTJXNrLAdD+ObVjxzIA4qcr+LKitgAPpjbopnd2YcBmmdAk7AMUXuv4ZN5QpLOwS+xlspn83n5BTP3KK4Z/+pNcLaog/4I/llQhoF/IgzsDaD9jvh9QzkpCaNAjaKuOB/QRoFtMPByp8FtuKHFO3kcxh6CKtrj30TuX9VKDeVAvrgHuUrYD3uStEO4exmYWDS3ssYLyK7HmK6ewBLU8pPpYBNGJNX3kuM5UL8maINwtLmi5ebiLeFh1+E25I6AzAdozEFf7e2kSxmgek4ssj9Nbg5hdxL8AVmJ+V3xAsO06yAz3A+7sPdmJainZLUay2wDPvnlYdjJlaIfGI+7YSl5H+Imq0FHsNxRe6vxHUp5HYTOcMcf4h1wBvCChbl3duO+3E5rm9NI1ko4IoMZLREOxH2XiDijo24VSjiQjsqAN6VYqilUUBuSHRI8WyO73FOiTprMBkLRFpuCEYIK1jZQv3fxEIoc+qZD5gg1hzvial3uMLrgD5Ykleumg/oK/L4leQJfxGmXYoRuFeM+1KMFo4zc+ppAUPES5UKurrjA+E4c1TVAir1AZtxdhn1VmMVnhDDoaVAp5sImG4VlpU5u0JOcBo+xKU4FB2T/yniy49s4Zm6WcA4fJJCbjFm4EWxDhgrTP4rERQNU+WN1V3BAtJQlgXs9nuD5QyBDmgSa/K2RJMyHHWpuXyoWI19nkWP6sDhIpp8L62AF8TObVtloHiHgpQaAusxCYuz6lGNORfrilUoNQTai8TEURV2pDvO03wUZmQiO5cRHiXm9txsM1ZEgPnL4TRsEBbwT4VyKmae5ti/P77E83n3nxV+JrfjcxZeqkXHajENnoaueCVpb66W1+1T8aiwhKX4XaS72jRNYl3fOylfgzuEd97ZAvrjpuRHxPhrRfa3zTJbxO9wiFBGZ4UVsIdIfuZye6PwdDU7WM0hMBT98JxwtnNwreJp8m3i8OQcEcQsxp5ird+m6CLMt19SnigyujkKWUCO2zUnUnvhIzGTZE61Tn/NFEnMeeKc0Qo7blt3wsdiuiMUMNiO1tETp4u9gTFi1XdllfqbKUPwpmblvopTd6pTygLgWBEL5OQsECmyTMnaB3QS5/KuErn6y8TpjxUpZK0Tw2hSUp4sEqN7V97N6nGnyNLAfsLrd22hXjkWQCj0fc0r0fF4MJOeVoFBWK7ZqubjzAJ1y1UAnCSywrmhsETsDWRCVkdkOuJJ4fwG40SRpiqWzu6B45PrnkXqrcKnIlJcLhzr3OTZtDvP/5HVLNBdnAHIKfRPsYNb6LhaV7Gb2zEpb8ON+LVA/SYRQTYl5X+SckUnQBs0aNCgQYPdnH8BtkPnN5mgDCQAAAAASUVORK5CYII=" />
                                    board
                                </a>
                             </li>

                             <li class="submenu-item">
                                <a class="submenu-link {{ Request::is('medium') ? 'active' : '' }}"
                                    href="{{ route('medium.index') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAHr0lEQVR4nO2be4jVRRTHP9frumJaGKSZbmqPNa0oLTErKYrIWttarcQeWkkRBpGZJb3UyFJ6oWCR9CAhKB9ZZFtmKbZalkVavtJK81U+2zXzkbq3P84Mv7nj7zFzX0b4hWHvb+bMOfM7vzNnzpyZhWM4BhMVwAxgN5ApUtkNzAK6lOidnFEB7KR4L26XXUrmfwYzkIHNBtoXUU4HoFbJmlZEOd7QZt+hBLIqlKyGEshyhjZNH6SBT4HPgaYlkFdU5DKgwUa/ISWQV3CkjN+ZkLo4pIGVQKV6/hnoChxy7K/lrQWOVyUF/IVMxw2K/3LgK2CZI9+c4ftFblf0a1TxtQLfVWMTMAW4wkOGF3wUkAZ+UvSDCabCWtx9gZZXCbQGHjPqJgPXAQ8CU4E/yFbGTY4yvOCjAP31w4qrFYTJewBoVPWjjPoU0B0YDXwMnKXqq4ABuE/bWNQBXzjQmV8/rKzBzQqiFH4PcFi19U/gsUvRfQac5iCzIDDnftqoTxP4gsEOfKIUUA5sUW39EnjUECihAbjRQW7eWEW0qWtfsMqBT5QC7lL1y3Az7fbItND8nnbsdwQWIdMgCXXAl4SbeVNgATDHgU+UAgYgX/VqBx4aKcR/6KnzBtDEo3/sgIqFYsirAfYpvm/ioIR8AqF8YcsrA6Yjwc+jjjwuB/oigdMu4E/gQmCE4jsOeNxnQFFfxHV6+MCWp+f+Esf+NwAHDD5hpRGPmCFOAT7m2gIYj4SvbxO957d5rlbPtzrIuBn4R9FPVfKmIFv6ecBSYKNqrwdOdRm4iwIywGYlsFkE7RSLfqmjPP01myeM8zZkv5FBTDwKKeAjgjghEa4K0GV8BG29aq9CVoOpjvJ0Nqp1zBiHEnj6J2LoNE4hiBMSp4LrFLiUwBJ8+cTR/aaeo6bMMIIweaQDf437VZ91RFtt6ICi2voQr4D9qr0zMJFoM7XlrVDPXUNo9R6hEXkhHzRDNmkZxNFGwncKPBtBW2vRrXeU97V63ke4vEKUX4BOEeOJVUCd0Z7kBNsiidU9wDdADwd5lcgaXqwXN8sOIjZOPktdIWDKm6l+FzMjbWaj3wkjOBpZ4Xr13FAi2VrujrDGWaqxtsgDqSDYvb2r6nytrx+Bs40r+5Hl2ESkrC4Ea6ZrWQK0sfgscuy7g0DRvgqo8lDAta4KAPk60whM0qX8SLYSkugbkC/fIaRPrvhA9U/KIOUka77qYO/P2yAvbyvBFPCk+q2jt0YkMmyX76AsLFP9o1acvGTpNFe3kLYwJZgCdPaoGhgL7CWwgkqDT9igrgS2A/eGyE3yAWFzP05WLHRsf2JEu60ELaC7+ruTIHfYGXhP8TQjvrBBXUMQ/Q2z2lx8wJiI8XorYI/q0DKGxlSCLn2M368Tv8uLGpSO/xsRhYShh+qrT47G4KEAl7yZ/nqHY2i2ISa73KirQ5Kke5EYfD7+B6gvA/chFhMlX4e2USG3jYV4Jne2IRpr60DbBlka5xl1OlO8B0l5hyEfJzhc9Z2onpMswBvakZ2dY/+Fqv9TMTS2AmwnZzu1fAKhLLhMgY3qb8eI9jOAh5E8gZ1Q7Q9cgljRcw6yNGxrKAd6xrT78PLOb05UTEZZ9ecgOT+dnsogSY0JwPlIllcfodle3EbcsVyhTdp7ug0l8LK3AJch+wadnTmApLN/Jdv89PHWakQZueKoK+BMwufX34h16JA2BfQGJpF9nF2T54CjFODiB7w2Q3HYoDqtQJabZzhyE2QiDVwFXO/IP25eRilA1ycVu593HACSbwdZ3johJzfbYugPA3ORTYoLLkacaBzKkUxUA9n7krGI9dllrItgVwXoDMogkvP2xcJI4BHgOHI4+CwEdNIybHOSL+LmpWnqa5EQ264v+hQAcW4gXyI2v15gLEYSNROAcyn8GaUzmiIntxnk9NVGGbIfaOHIL41El0PIzTMnLY9R7fmE3VSrzvUEJzjNkUBnvWqbFN41Cy8h9wFtc/VBFeIQ7ZRXUnteCoAg/TQXeIgg4NFlTUL/FHBQ0a5DUnA651CqrHB9EmEczANHXb5DLii5pLdbEuwONd5SdcXMSIdlo3NGFUGe70WjfraqGx3Tt72iMc8WK4CtRHty2/H1Ar6PoY8rZjY6L+ibnfsQ5wfZDq2W8JPebqp9pVXfEdlc/R4xcBB/M57sDZhrCctG541JivlexEGCKMG8uzfI6tNbtS12lKFfoBfBKnQIUYQdlFUTONfJlOC+UwpJW+lBDVd17YD3Vf0mq09fVe9ylQ4CBeivvhJRho0RBNPyeUp32QuQ2xp6ezwTOIngRRdYtANV/XRH3qYCwr56O4JjvUYKmArzRTWB6W9HvnAGWfNNaAXsBe504DsfuWdkf/U0kqvQMrcSnTkuGTqSfW1Vm6OZDS4DXjXaX/GUUQbcQfaF7TnAyfkMvNAYiNzG0APcjJjmeQRz80PVdhBo5cCzJ6JMff0tg6ThayjxfHdFGXA3gefWZQvwifE8Dkm5N0f2EW2RGxxaKeXAtxaPFcit9aOyLfZFCrnS+hpH/udHXPlB9W+FxAabgBdwOwD1Glwp0QSZBhcBFwCnIxmmE5B/mjqI3FTZjSyj+jpcGbLENZZ4vMfwv8e/QCDg5+L9p4cAAAAASUVORK5CYII=" />
                                    Medium</a>
                             </li>

                             <li class="submenu-item">
                                <a class="submenu-link {{ Request::is('period') ? 'active' : '' }}"
                                    href="{{ route('period.index') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADoAAAA6CAYAAADhu0ooAAAABmJLR0QA/wD/AP+gvaeTAAAHSklEQVRoge3aeYxdVR0H8M+0QwuVQovVLiyFFqGAytIQrDIFo5gigogLIopo0ZSINS4oqH+IitYQlxgjSo3EuCaKW0EMcQOUSLSIidCCaN1oS6lMa1uEFjr+8b2Pub1z35s3j5n2JfWbvNx37zm/c8/vnN9+LnsJemqeTcLE3T2RMcajVUYPx/3YZw9MZiyxobfyYIowuRCP7v75jAlOxPIqow3cjS27cTJjiUkwbk/PYndhr2G0mehW8XycOZYTaRO/wy86IWyX0ctwHv7WyUtGCdPxLyzohLhdRntwIy7u5CWjhPfhNZ0S7zU6utcw2q7odgv2xbHYD9vwV2xvh7BTRsfhhcWLy9iOO/BEh+PWoRdLit9c3FNqexzL8JF2BukE83F7k7Yz8LMOx61iOm6SGPwLWIHVspAHyWJ/Q9zOTa0G6pTRCcV1PHaWnm82eplPr0z+CRHXDZX2dbgBr8d3i/9L0d9ssLHEm3BRzfPb8dFhaN+GOTgKG1v0eytOw8eF2ZdgoNpprK3uOZIRrSz9duDCNmgX44uGMvkZvLZ0v0V8/Dk4BS+vG2x3WN1f44rS/WK8v9JnESaX7ntxAt5d6Xe5RGmXyQIuL7X9A7cIo0P0tRvcyxG4WfS7oe+9ov+r8GzJj8/HK0UdpuDzIrbfFAN1K+7F8XUv6QZGG9WMo/FQ8X+BuKkt+BrOEkv+IrGwivuleIfo8fnibvare0k3MFqH/xTXKWLFvyRiW8Zf8K7i/xrx6TMNtc7o3hDwfhHls0dAM1FSyVr/3q2M7sDD+CxOapNmmfjcb9U1diujDdxi0DC1wnj8SvzpproOe0JH1+LvbfZdIcn23BZ9JmMGPocHm3XaEzt6M142gv7fF994cpP2KyWouLPVIFVGByrXbsCt+J7B8K6BXnxIKg9LDZMxVUV3Fd6MrTV954vCw8HF9ZN2XZSJUm7pK+6fJ5nHMs1xUHH9sOSYDTxTQr15WI9DxXeuLu6Pw7NwnSxES9SdvdThPFzaZt+xwkvxFgkIDhTfuURE9ooWdH24rfrwGZL2dJM1PgnvFcnpq7T9WGLpNwjzdehTo4qn40nMHrVpdo55op9PStazAVeX2g8qnq0UUd4qhqm6SbWMwgGjO9+OMB+PyI7NKZ69Sko114sRWo0/iF3oxRvF+n7brsw2ZXRPY38plF+vfne+g59L4l7dlGNkgd5ToRkoG6MJog8nyirOFJ0dkJVcK1W3u3GXXY8V95ddOL5EO6Gg3Vaivaug39GC0Ya7OAqPtejXDItxDQ4Tce7DbT14tZQ7zhCL9meJMNaLKOzENMkLD5Z06gkJue6QXHGhrP4qiWQ2Fr/x4gKmi3uYWzD+U0m/VtRM9LcSVFzVAZNkgR8WN/lDJav7pEQfF2JWGwNNk8X5quzYdZIQT22D9hBZ1BslO6nDZoPlkIsksR4Oz8EDBt3lrfhg8f8pHa0z2+1gdkF7aAe0i9QfNPcUY16LD8jOD/GBNVhQ0C3B2/FHfKpo68NAtybeLxb9miGBwXBo7OQlxfWwaocqo+NEj55bvKRh1TZLHfUeyezrzPU4HCmhWZV2rdRzmtFWcYnBotpZbfRv4ORi/B9VG6qMXioV8U2SSjVi3v0lZj1Q6q1fqXnJUkmU+0u0PQXtEcL4xWKERoJ2wtRh+1QZXS6GaV2T/rPEotXhWvFx61vQlus5EzQP9pfgFXiB4ZMCdk0ySGV/ekF3CIPKv1Dzs5RmmC2O/TD8c4S0i8S1/GCEdJ1iXTNjNEFWpFFU3iI71crR19EOFLQP1dA+hteNcMJPC2X3crbEkDuK5+XfdgkIFhV9q+7lXNzXgvZeSbVo7l7GDNUdvU/ONlaLODYKTVNFRI+RUmQdVuPTBqOjMu1syUYeGK2Jd4JuChjGDN0aMByAdxbXKU9jnM1S5727yujRcnDTcPqN+LXfoNNfLo6/imOk1HFsiXZARPhBEekvGz7SORVfF4npl5SsXYyTOPwG/Lvg505cUGX0qGKi90oGUXb6s6XYdaR6Ro8WPbynhvZw+fpsjuaM7iMZy+WymDdJhHO1xK7tYHLB6MdKNFfhE3SHjs7D7yVQKR/k3mBkn8QdUMypfHR4LjZ2QxHsWEnIH5dd/0mp7UoJ8E8f4ZjleLpHi+xlktRVp4nB2iCJ9LYm/cuYLMn2NPGpG0Vfmn3ovEY+trhAUqxlkiOTgvUm/KmN99I85n2K0RMkrlwoh63NkuitUlW43aCeLpTEt68YY1IT2kckI7nNrrWg/0o1YIWcg54pCXe/1IWu0vpjjeEwFZt7ZPUG8JtiEiulnLJWDmR3iomfISncfLGMp4kBeRy/LOhXSm1oQzHR8ZLxHCyLcXJBd4roaNV1zJKi2IJirOPkI4xWoeeA7Pj2Yrx+kYw1xf01outOlXrQSDFFRGvycB1rMFN2vw494kO3GRpK1v12isEhpc+NpbZH5MuW/do9ktgT2NfQ7xFqP5b6P0r4H6lnuGSVE+rbAAAAAElFTkSuQmCC" />
                                    Class</a>
                              </li>

                   
                         </ul>
                         </div>
                         </li>



                <li class="nav-item has-submenu">
                    <a class="nav-link submenu-toggle
                    <?php if(Request::is('subject') || Request::is('lesson')){ ?>
                        active collapsed"
                        href="#" data-bs-toggle="collapse" data-bs-target="#submenu-2" aria-expanded="true"
                        aria-controls="submenu-1">
                        <?php  }else{ ?>
                        collapse collapsed" href="#" data-bs-toggle="collapse"
                        data-bs-target="#submenu-2" aria-expanded="false" aria-controls="submenu-1">
                        <?php } ?>
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAABV0lEQVRoge2aMU7DQBBFHwjJQoAEEgVSGtqU3CJUkbgHNClyhtwpB0gkinQpaCA5AtDQJIXXiot4cWZ3vWNpnmS5sHb0n72etWyD0T8K4BVYAD/ALvMmYgCsFIQPEilqEmtgDNxICkVCLPLGQeI2ZiIhYpGlGziOGkeOWOTbDcw5neqIRYK6RAK8ec6FRUfAlvAOdGzbuPrR8J2BTSKJuswpecQiKaddU+0kU0sdJqINqcjW7VM9S1X1o+C7uUak61xN7dcWxF5hItowEW2YiDZMRBsmog0T0YaJaMNEtGEi2mgjcg1MgXfgl7SvSv97u9LImedYNfgTeGwh3BW+zEepn40F8AzcRw7VCZXEHLjInCWISmSYO0gof5QiRe4gbfB1rS+3f+oiSEpmlFdkBVxmzhLEHYfvhGvgBXjImiiAIfBBvkXw5IXRxxUwofyBoLc/1Rhdswc810cdKdAPjgAAAABJRU5ErkJggg==" />
                        </span>
                        <span class="nav-link-text">Subject Management</span>
                        <span class="submenu-arrow">
                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down"
                                fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z">
                                </path>
                            </svg>
                        </span>
                    </a>
                    <!--//nav-link-->
                    <div id="submenu-2" data-bs-parent="#menu-accordion"
                        class="
                    <?php if(Request::is('subject') || Request::is('lesson')){ ?>
                        collapse show
                        <?php }else{ ?>
                            collapse
                        <?php } ?>
                        "
                        style="">
                        <ul class="submenu-list list-unstyled">
                            {{-- <li class="submenu-item">
                                <a class="submenu-link  {{ Request::is('book') ? 'active' : '' }}"
                                    href="{{ route('addbook') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAABV0lEQVRoge2aMU7DQBBFHwjJQoAEEgVSGtqU3CJUkbgHNClyhtwpB0gkinQpaCA5AtDQJIXXiot4cWZ3vWNpnmS5sHb0n72etWyD0T8K4BVYAD/ALvMmYgCsFIQPEilqEmtgDNxICkVCLPLGQeI2ZiIhYpGlGziOGkeOWOTbDcw5neqIRYK6RAK8ec6FRUfAlvAOdGzbuPrR8J2BTSKJuswpecQiKaddU+0kU0sdJqINqcjW7VM9S1X1o+C7uUak61xN7dcWxF5hItowEW2YiDZMRBsmog0T0YaJaMNEtGEi2mgjcg1MgXfgl7SvSv97u9LImedYNfgTeGwh3BW+zEepn40F8AzcRw7VCZXEHLjInCWISmSYO0gof5QiRe4gbfB1rS+3f+oiSEpmlFdkBVxmzhLEHYfvhGvgBXjImiiAIfBBvkXw5IXRxxUwofyBoLc/1Rhdswc810cdKdAPjgAAAABJRU5ErkJggg==" />
                                    Books
                                </a>
                            </li> --}}
                            <li class="submenu-item">
                                <a class="submenu-link  {{ Request::is('subject') ? 'active' : '' }}"
                                    href="{{ route('subject.index') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAABV0lEQVRoge2aMU7DQBBFHwjJQoAEEgVSGtqU3CJUkbgHNClyhtwpB0gkinQpaCA5AtDQJIXXiot4cWZ3vWNpnmS5sHb0n72etWyD0T8K4BVYAD/ALvMmYgCsFIQPEilqEmtgDNxICkVCLPLGQeI2ZiIhYpGlGziOGkeOWOTbDcw5neqIRYK6RAK8ec6FRUfAlvAOdGzbuPrR8J2BTSKJuswpecQiKaddU+0kU0sdJqINqcjW7VM9S1X1o+C7uUak61xN7dcWxF5hItowEW2YiDZMRBsmog0T0YaJaMNEtGEi2mgjcg1MgXfgl7SvSv97u9LImedYNfgTeGwh3BW+zEepn40F8AzcRw7VCZXEHLjInCWISmSYO0gof5QiRe4gbfB1rS+3f+oiSEpmlFdkBVxmzhLEHYfvhGvgBXjImiiAIfBBvkXw5IXRxxUwofyBoLc/1Rhdswc810cdKdAPjgAAAABJRU5ErkJggg==" />
                                    Subject
                                </a>
                            </li>
                            <li class="submenu-item">
                                <a class="submenu-link {{ Request::is('lesson') ? 'active' : '' }}"
                                    href="{{ route('lesson.index') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAACoUlEQVRoge2Zv2sUQRTHPxc1RCJWxiABtRItJIiCBCwULaKJYmOp6Wz8AwxJk8JC0mjsUmoltokKhnSRFNokmIDYaCKKgkZFMSTmYvHektlj725nd2YzB/eFZWHmvfm+787b+QlNNNFEVvQCy8Cm52dJubxhqQARphhviEh8wwlPi4NAgkBIQoaBE0DJdcNFp1b0fAEeAdeAvS4JfCPiGQc+Ehf1F3gO3AIO5yXwDZOnhKTXMDALbBAX9ga4C5zOSuATtXg6gAHgCfCDuKgRFwQukZZnF3AOuKf231wT5IUtT4/avzULQxp+0+Kyvp+mdQi1R+bV/rwvAoAjGfxs7A+q7U+g1axwmVp7gDGH7SWhX98vgLW0TjZfahL4Tnx49MHzTG0HLNq3IkhamrvmaUdm+g1gv0X7mX92X0Kuqt3LpMpGGn779D1p6xhSj5TYWlAe9x1QVr809qfU5kM1g0ZJrWjYncjiHFKPvFabixniCUbIAaAM/Abaqhk1Qmr1Iz/7FLBazahRhIDFarcSIax+25CUKgNdPghcohbPJa17Va+R0FMrSivr2dxECD3yXutO+iJwiWo83Vr+iRSnjyGnlplWuT7odvfIrJZf8UXgGkk8HcgGahXZQtdFqKnVh8Q2jcwjdVFLyLK+k7axLh+TyxQCOWZzE70Uc/1WeYfYihz3bAKHXAhJQjty0jcOfK4I6A+yX7hJjuUEcEHbm8sVqQVakIlqBNkvlIkLW0CuAM5gdwt1X/3vuAzWBp3ADeQK4BdxUV9Jfwv1Tn16vEVqgd1Iiowh+2xT1DowA9wGjlb4HWNL+I6igrVBNzCEnEn9Iy5sERgFzgKDWvZwe8K0wz7gOvAYWCF5JMs9mxeNnUhPjCKDwwrwAA9X1E0Ujf+HL1vpX4px4QAAAABJRU5ErkJggg==" />
                                    lesson</a>
                            </li>
                           
                        </ul>
                    </div>
                </li>



                <li class="nav-item has-submenu">
                    <a class="nav-link submenu-toggle
                    <?php if(Request::is('school') || Request::is('location') || Request::is('timetable')){ ?>
                        active collapsed"
                        href="#" data-bs-toggle="collapse" data-bs-target="#submenu-4" aria-expanded="true"
                        aria-controls="submenu-1">
                        <?php  }else{ ?>
                        collapse collapsed" href="#" data-bs-toggle="collapse"
                        data-bs-target="#submenu-4" aria-expanded="false" aria-controls="submenu-1">
                        <?php } ?>
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAACS0lEQVRoge3YO09UQRjG8R8XCxEQY4wWWtCIFlQSGy00Qb+BlYWdpQkWFiZaWtiY+B3sqCioNBoFIwShRCURChM1MTHxtgXeijMblsNZdjmcXQZy/skkk5k5z/s+Mzm3l5KSXUc3ruEdFkO/e0cz2iKduIK3+Jdqy7guckPVE1iylvhSGKs3HpWhrBPI2vlm17WdvIlFY6ioRHbMUKsCt81QuwK1LM5OHX1hcWO5GXPnEYuB3HnFaiBNwzxnaiaifOOmyPqCeNWBlziMe3iE3zUXHcdFnMEQBtGLA2H+J37gveTjcA7P8KFBMkXoduMqbuNLVpA+3MR8jeOttvmgMVCjO1Cgbl866Y6afg9u4QYOhbGPeIIpvAm78y3sGMkO9uMkTuMcRnEszH/HgxBnTLLrReh+xUPcx6+0qdng+g/GJUffmV7UBJ3h2vGgVd3NVujOZC2sYBXDOYLUYzhotkq3kjVZqTexTdqim+eIo6Q0EhulkdgojcRGaSQ2SiOxURqJjdJIbOwZI43KPidwQeNqx7Kk3vQaTzWuorRKF2t/XP2SQsF2qx1jkmpHq3WxvopSwT5JjehoGPuMx5Jqx6KN1Y7eIDqEUzgvqXZUr/+EI6HfCt1V7Jei6vovJnAJXelFTdCFy5i0cUcnC9CdCDlWNTdQnRjJEaQeZyVVwtnQL4oRTRjZLazLN+vxm/dGrG1TMsqaYWy6oBh1eVFQgGqbk9ygPZLH6mgYKzLG880MbZdBrGwSfCWs2RUcxF0sWHu5LeBOmCvZ8/wHnBqGyyoum5EAAAAASUVORK5CYII=" />
                        </span>
                        <span class="nav-link-text">school</span>
                        <span class="submenu-arrow">
                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down"
                                fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z">
                                </path>
                            </svg>
                        </span>
                    </a>
                    <!--//nav-link-->
                    <div id="submenu-4" data-bs-parent="#menu-accordion"
                        class="
                    <?php if( Request::is('school') || Request::is('location') || Request::is('timetable')){ ?>
                        collapse show

                        <?php }else{ ?>

                        collapse

                        <?php } ?>
                        "
                        style="">
                        <ul class="submenu-list list-unstyled">
                            <li class="submenu-item">
                                <a class="submenu-link  {{ Request::is('location') ? 'active' : '' }}"
                                    href="{{ route('location.index') }}">
                                    <img width="25px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAGJklEQVR4nO2baWxVVRDHf20pi6ymKMYAYiOgYhVThS9qQBG1gihuaNAYl/jBxKXVaFyiCZiYENyQuEXEJZgY/WAUMKIiqYKAgiAqCm4simKBtAoItPXD3Afn3d57zpy7vH6QfzIp4Z2Z+c+5754zZ848+J+jrLMJONAXuAiYCAwHjgWqgCbgN2A98C6wEGjuJI654GhgFvAv0K6QvcDTwFGdQVaD7sAw5dhbkaepCTwszcAtWRJPgxOAeuB9YDdCcLZlfJfg8ySBh2VWYK/kqASuBD4E2iKIfW3RfTVifBqZm2lkDpQD1wO/WgitRxazKNxn0Usj92QaZQzGAGsinLcCC5B3+niLfm0wNo8JOACMzCrQMLoBMyLIbwemA8cp7XxMPsEXZFGqKGNQDXwVcvQP8Ciyd2sxjnyDL8jYpIFGoRbYFnLwATAwga2X0AWwHdlRhgBdg7/1wF9K/RcTcIvE+UCLYXgvcBfJMspKdAH8CAyOsTE4+Fwzgam3xdHI17xgdCeyACbFSNzE24AzHXZGEb3lhuW0FFwZCvxpGNsK1KQxCFyGm/QSpa0lCluXRimWK4z3BN7jUJ69CxiPPanRYIhizEqlrS8UYyK3Ys0EPM6hPH4/kul9o+NlRc8MbBSgWYOOiPpP1wRMoPhw0YCkuVlAc3x1vf8FnKEY87fS1kF0pzi1XUS29YMJuN/bLBfBuDQ8FvWGcgswyNeAA1XoUuAstsFWPGsFfSneo6f5KHtgJW7y7QGXemQh6xr8bUCfCK3yJXa3obwD6JcsPiemowsgrTzmQ6oM2GAoP5I8PieGoXt/00gbcJIPqfMM5QNk/+6HsYh8J+AjX0JmWWp+4rD0mEy+E3C5L6FfDOXJicPSo5zogkoWshZdsncQJxrKe4AeCYPqB0xBFtOJQIVj/CXkMwGTfIlPNZQX+yoHuBE5KZpEVuOuFywl2+CXkSBxm2kYmOGrjAQft6p/jtQA4lCLLLpZBH8gsOdE+Kt5J3L0BfgZeWpjgLOAY4CNQYBR6I+cGuNem4HAJ4HdKPyO3AiN0hB3YDYwJ4niKuwzazN6g0O3HbjG4b8fcueX5ulvwa8uWYStDuO2lPIVBbnTFRzqSJ4ctSG1isTY5XAwz6L7g0N3hQePFxy24sR29abCDovxVuLraoOwP7Vm/NLRXsB3FntRso4MiixNFgcvW/SmWfT+QF/YMDGC4gq0TZqRHMaG2oDncNsg29e4OkanLxJklM5G5JY4KaZY+JhylcNOFw4dnb+1DVxscRJ3JH4yZnwT9jtBLZ6ycGoP/Lsw3Bi/yTbQdkUdddM6nvjk5TYFMQ0qgcYYH43Yk6sCzPKbtabZEOOoHakI3wv0QQ4YddjXjCvUIbrRB3gt4NAO7EOu1Xop9R8yeD1jG3gO8QEVpA25EnON24bMfJY4EjgF/0RngcFrqm1gL3TB+cg85Al2FrpR3HMUt5gfhDlbWcla8qsrunCxweP78IdRxYJ3ciBRg2dhMkNcbfz7bY1Cf6QYkvW3YC+l7+OrojiWU7WKmoNNErkwfUxeeNDw3eijOIp8JsCVsWWJKooPd96+55P9BIxLEZAvnjD8rsGzOAqycGXdvjYgRUA+GE1xhup9MVrAc2QX/NKkJDzRA+lfKPhdmMZYb6SGl8UEXJuGiBJlSOJV8NlM/M2yGmNJX61dTYJ3MAEeCPm9KSvDZq+Ar+wmZYeWEreH/D6btQNtU6MpTaRrpdOigeKS3GJ0x2QvVCBHUm3wbyJ1/jzRBTnehhfb3nk5rABexx74cuDcvAgYOBlpjzN9f0oJTp5lwMN0rAL/BJydt3Nkm7ufjueVucjRt2SYRMcenRakoySPp9ANuBnYHPK5B7gjB38qDADeouNr0AI8j5wp0rbWDUXK2VGV5+V4tr/khTpkr49aE7YgNz3XIeUsV9d2NXJwmUn85chmZI939R2UFOVI8WEZ9kVyH3IH+SXSH7QCWcw24f6d4AbkBjtp40bJUIP8kDH8viaRXcAbyC9IM88mS/HT2RrgAuR6bATSGheXpLQir8w6pKHiM2Rr258Xuc747XAlkiD1CaQCSZd3Ir0BuQV7GIfREf8BBpIW5sZoywsAAAAASUVORK5CYII=" />
                                    location</a>
                            </li>
                            <li class="submenu-item">
                                <a class="submenu-link {{ Request::is('school') ? 'active' : '' }}"
                                    href="{{ route('school.index') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAACS0lEQVRoge3YO09UQRjG8R8XCxEQY4wWWtCIFlQSGy00Qb+BlYWdpQkWFiZaWtiY+B3sqCioNBoFIwShRCURChM1MTHxtgXeijMblsNZdjmcXQZy/skkk5k5z/s+Mzm3l5KSXUc3ruEdFkO/e0cz2iKduIK3+Jdqy7guckPVE1iylvhSGKs3HpWhrBPI2vlm17WdvIlFY6ioRHbMUKsCt81QuwK1LM5OHX1hcWO5GXPnEYuB3HnFaiBNwzxnaiaifOOmyPqCeNWBlziMe3iE3zUXHcdFnMEQBtGLA2H+J37gveTjcA7P8KFBMkXoduMqbuNLVpA+3MR8jeOttvmgMVCjO1Cgbl866Y6afg9u4QYOhbGPeIIpvAm78y3sGMkO9uMkTuMcRnEszH/HgxBnTLLrReh+xUPcx6+0qdng+g/GJUffmV7UBJ3h2vGgVd3NVujOZC2sYBXDOYLUYzhotkq3kjVZqTexTdqim+eIo6Q0EhulkdgojcRGaSQ2SiOxURqJjdJIbOwZI43KPidwQeNqx7Kk3vQaTzWuorRKF2t/XP2SQsF2qx1jkmpHq3WxvopSwT5JjehoGPuMx5Jqx6KN1Y7eIDqEUzgvqXZUr/+EI6HfCt1V7Jei6vovJnAJXelFTdCFy5i0cUcnC9CdCDlWNTdQnRjJEaQeZyVVwtnQL4oRTRjZLazLN+vxm/dGrG1TMsqaYWy6oBh1eVFQgGqbk9ygPZLH6mgYKzLG880MbZdBrGwSfCWs2RUcxF0sWHu5LeBOmCvZ8/wHnBqGyyoum5EAAAAASUVORK5CYII=" />
                                    school
                                </a>
                            </li>
                            <li class="submenu-item">
                                <a class="submenu-link {{ Request::is('timetable') ? 'active' : '' }}"
                                    href="{{ route('timetable') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAACS0lEQVRoge3YO09UQRjG8R8XCxEQY4wWWtCIFlQSGy00Qb+BlYWdpQkWFiZaWtiY+B3sqCioNBoFIwShRCURChM1MTHxtgXeijMblsNZdjmcXQZy/skkk5k5z/s+Mzm3l5KSXUc3ruEdFkO/e0cz2iKduIK3+Jdqy7guckPVE1iylvhSGKs3HpWhrBPI2vlm17WdvIlFY6ioRHbMUKsCt81QuwK1LM5OHX1hcWO5GXPnEYuB3HnFaiBNwzxnaiaifOOmyPqCeNWBlziMe3iE3zUXHcdFnMEQBtGLA2H+J37gveTjcA7P8KFBMkXoduMqbuNLVpA+3MR8jeOttvmgMVCjO1Cgbl866Y6afg9u4QYOhbGPeIIpvAm78y3sGMkO9uMkTuMcRnEszH/HgxBnTLLrReh+xUPcx6+0qdng+g/GJUffmV7UBJ3h2vGgVd3NVujOZC2sYBXDOYLUYzhotkq3kjVZqTexTdqim+eIo6Q0EhulkdgojcRGaSQ2SiOxURqJjdJIbOwZI43KPidwQeNqx7Kk3vQaTzWuorRKF2t/XP2SQsF2qx1jkmpHq3WxvopSwT5JjehoGPuMx5Jqx6KN1Y7eIDqEUzgvqXZUr/+EI6HfCt1V7Jei6vovJnAJXelFTdCFy5i0cUcnC9CdCDlWNTdQnRjJEaQeZyVVwtnQL4oRTRjZLazLN+vxm/dGrG1TMsqaYWy6oBh1eVFQgGqbk9ygPZLH6mgYKzLG880MbZdBrGwSfCWs2RUcxF0sWHu5LeBOmCvZ8/wHnBqGyyoum5EAAAAASUVORK5CYII=" />
                                    Time Table
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="nav-item">
                    <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                    <a class="nav-link  {{ Request::is('academic') ? 'active' : '' }}"
                        href="{{ route('academic.index') }}">
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAAGZElEQVRoge2ZW2xWRRDHf7S0RaBQjQEieAlglMJDTRSKpQHEB6JRkEtNNEg0RhS5PgghBOQBtIqIRokJIREDgpgoisYoIRJvQesVlVIQSFBuIgW5fyj9Ph9mlj093T2Xlo/4wD/ZnO/bmdmdObszO7MHLuMyLiMfKAGmAl8Dp7RtAaYAxQnkrwIWAvXAWaAR2AiMBdrlQV8negI/ATlP+wG4JkJ+IHAoQv4d4Io86X4BJVgjtgGjgFJto4HtSvse98pcBxxRnk1AFdAB6AY8BvyltJX5NAJgmk5UD3R10LtijXnSQV+ptPVAoYN+M3BceQZfBH29+EYnGRXBc5/ybAn1d0B8qQlZGR8WqvyrrVczHid1ktIIni7KcyLUf5P274iZY7jybU6jWEEaZuRtxsFEnTDv+ZRzZdMwpzVkuz5HRPAYWn2o/w9ka/UFro+Qv1Of21LqlgqTkWXfjtvZy5CtkwMed9BXKO193M5ejmzJHBKm84Yi4DudqAFx7C7axmCNqAPaO+R7YEPsp0A1EgS6I4Y3Km1FPo0w6I5sG9+BVo+cCz5UAIcj5DeTLDtoE4qBpYjj+hT5F6hFDs8wSoDnYuSbkNDrkr9oRnyik2WA14BK4EokHFeqAv9g/aAoIF8EfKC0c8ArKlOqY1TqmBnl2UieVuZlnWAfcGsE3y3AAeXdCxzTtlf7DiDby4eBwH7lXdpWpYcAb+mAGVWiCXmTt8XI3o11WldrBO6KGWOgztWkc2eQF7hWdYtFe2BZhBJZYDHu0Alwj05u8qmhQCdtw4D3sH7gM6Y98ILO5dNjGe6oeAHGiNPAPKA3sk/76P/TSl/skO0GHFX6UxFzzMauzNUO+pKQDn0COswHzgSMcWJIYIBBHp5KpWcdPHOxKxGHDco7J9Q/WMc+rXO5cDvWmCoXw1olzotRYr7yrQr1f6v9Q2PkwSaGdaH+NxPqsED51riIJlL0jhmkr/LtDvWbbdU5Rh4k5JrtFcQe7e+TUId9LqKJ33Gxu0T5zob6j5HekGMeHeIOww7Y8wxonv0e1Oe1MYMY+sFQ/x59Rp0xBiaEu1YVogsvgBv0edh0BA35Sp8PxAzyoD6/DPW/q88ZMfIAM0MyBl/o86EYeUP/zEVMEjEGIxEj6+Dpjr1YmB2hxBzlOULL5LJax87gDxrDkcMyi0QwJ17EhuD52BjeF3gaG/aWeORHYRPCDTppZ213YHOt88C9njEeQe63ejloNyIOnkNSJi8KgZfwn6gm/4mqLMcTfSpnVdHWohjJCiKr2yHALxFK5JB7Ld+SPopNGKPaXqyvhZWsQc6HBuwtZgNyxtSQICN+GKklcsAuZC9XI+Vntf7fjU3DJ4QUWBdQtA54AuiHzbX6IaXyjwG++wNjjAmMH9V2IZWpEyORRC4LLKJ5HRFEMVI0ZdXoEcgSr9dJjiNvLQrtgInAGypbADwfUHQrchFYHngJ/YHpwM8BvlpC26sT1oHmxihhME/592Cj0FGdMC2MERlgUli5EAqQlTYHZ22QaG5G6kh+E16AvYQwbWRy3S9gDNaIJDmawTCsMaNN5ybtcDlfFCZgjfgopSzINjU+MSmhTFfsYWgW4DfUFcz1TM+UivTCGhLnFy7UYH0iyUVhEVLH54BZyFFhIuw4sBWdr+rzoRBrSFx+5sIalZ2WkH+58h/C5loztG81AWVaAyMbWXZ6YC7zyhPwzlLeMzQv6Pprf0NQmdagLbLmajR4s7+AloaNRXZNEy0zAlMOnGirMhfTkPH6/xRyzoDcppj8bpZjjGaGmNN8K/As4jgVyD4sU4Ey/V+h9Frlb4sh4a3VEXg9MOZq7LfG5Z4xBhDYWlOBPwMDtKa5bubjYOrz6aH+iciqmLE34s80ZirPKnMAFiPpxiCkwuulypVp+zvQ9iOHYR1yiVeKlL2fI4XRDiQfalSFTiLhtbOOdR74HQm/65AQWkHzDzvlwNv6uwpJfcIoRHZFf2RbtglVwMdEX0qH2wHkxRWrwTkk7QijI9Gfuaeo7E78K5YaPZCIsgj4EEnuDmEvJHL6+yBSBpjq0nw4zSBpR1IEq0RfgXbJUYs1ZjLRB3MhshLnVOaZvGuXAgVYY3KIz8xA9r4pkwcgjv2r8mQRI9J+A70kGI0kgHE+tpP/0XbyoQg5p1YjH1xPaqtHrmjH4XHs/wC3RmSbC70wEAAAAABJRU5ErkJggg==" />
                        </span>
                        <span class="nav-link-text">Academic</span>
                    </a>
                </li>

                <?php } ?>



                <?php if(session('Role') == 0){ ?>

                <li class="nav-item">
                    <a class="nav-link  {{ Request::is('section') ? 'active' : '' }}"
                      href="{{ route('section.index') }}">

                        <span class="nav-icon">
                          <img width="23px" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAABTklEQVRIie2VP0vDQBiHH0tdanHzsLOLn8EUBN3chX6D7o5OfoLS0snJrYM4Cro4F/9MWhBcFYUOleIguMQh78FLTMxdmkzND45c3tzvnruXey9QaZnVB0JpfU/vLTDOA60Bbwr8LjFXWZ+32mI8B16kHxQJTtvFoTxvgMtYrDTpNG8B+/inO1eqAzH9AKfAmZqoXSZ4oIzxNigLrNO8q+LH+KXbG2xP8wyoq/gOfunOXU6LKnc5la4KDHBCejl1iwLXE2LfwKd6XwWa0v8oCpylFeCCaLcjD9/C5XQkE0yAtX/GjYEHwCSAjXxz/j8HRPf1F7CdMfZeQE8CsmAjsRC4c4FuAK9i6DiM1wD7DGMxk+oW1YBrMQxdVqkW+8jfSngGNl0m6CrTnOjetq2X4TVE50HvOHGnSeXUUv312LdGBngK7AFXAj6QWKUl1C9lk3i0zGm76QAAAABJRU5ErkJggg==" />
                         </span>

                        <span class="nav-link-text">Section</span>
                    </a>
                 </li>
               
               
               
                <li class="nav-item">

                    <a class="nav-link  {{ Request::is('classbase') ? 'active' : '' }}"
                    href="{{ route('classbase') }}">
                        <span class="nav-icon">
                          
                            <img width="23px"
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAABTklEQVRIie2VP0vDQBiHH0tdanHzsLOLn8EUBN3chX6D7o5OfoLS0snJrYM4Cro4F/9MWhBcFYUOleIguMQh78FLTMxdmkzND45c3tzvnruXey9QaZnVB0JpfU/vLTDOA60Bbwr8LjFXWZ+32mI8B16kHxQJTtvFoTxvgMtYrDTpNG8B+/inO1eqAzH9AKfAmZqoXSZ4oIzxNigLrNO8q+LH+KXbG2xP8wyoq/gOfunOXU6LKnc5la4KDHBCejl1iwLXE2LfwKd6XwWa0v8oCpylFeCCaLcjD9/C5XQkE0yAtX/GjYEHwCSAjXxz/j8HRPf1F7CdMfZeQE8CsmAjsRC4c4FuAK9i6DiM1wD7DGMxk+oW1YBrMQxdVqkW+8jfSngGNl0m6CrTnOjetq2X4TVE50HvOHGnSeXUUv312LdGBngK7AFXAj6QWKUl1C9lk3i0zGm76QAAAABJRU5ErkJggg==" />
                        
                            </span>
                        <span class="nav-link-text">Add Class</span>
                    </a>
                </li>
<?php } ?>

{{-- <?php if (!empty(session('SchoolId'))) { ?> --}}


                <li class="nav-item">
                  
                    <a class="nav-link  {{ Request::is('student') ? 'active' : '' }}"
                        href="{{ route('student.index') }}">
                     
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAHzklEQVR4nO2ad4wVRRzHP/fuKIcUD0GaZ0URQQFR4im2KGCJFXtALGBAgyiCxoIBRDExlmjEgiVg7IoaLFhQFAQLCKgIEiNgQeCQKkdR7vnHb8aZfTc7u4+33D3wvsnm7u185/f7zezM/Mou1OL/jcIa1L0n0B04AtgGrK1BW6oNxcBZwCvAViBtXQuAkcDBNWbdTkJ94Hxk0BWYAf8DTAPeBNZY9yuBWcANQOsasDcRFCLL+wlgPWZw24EZwBCgZQb/VGCih9+immzfYRQCpwDjgT8JLu8vgaHAPjHkNAQGA68Dmy0ZfwNTgCuQ8yNvUAY8AqwgOOj5wG3AgTFk1APOAJ605JwGNAb6Am8TPDO2IFvnUtW3xnA7wUH/CIwCDovZvwx4GdiQIWcxcGgGtynQH/gIOT8092tq0Jt9pYz4CxgEFGTZfyZmIHOAEYhbjEJXxGvovvtnqTcxDCf45H4GxgKdY/bvBAwE9ovB3Ru4FvgMORy1zplAKiurE8ZRwAPArwQnYyHi19vnILsEuBr4gOCyrwBeBXoDdXKQnwjaA/dhtoPrmgfcChwQQ14joA8wmarBkn2tQrzLWODwxEYTE+2AMciTsZejfV0MPE0wyEkDXwA3EnSJxcAFwGtUDZY+RFbBnBA9Onh6k2oKnK5HfLLtkh4HegAd1L01Fr8uEv4+D2y0+m1HIr53CHqB7cg+vw7Z9xrPqPaB6ncJcBLwkNV/NXB0gmOtgl7IbFciUVufDCNPwDxlF4qBC6ka5KSRLeQLlm5WvAcdbS2QiUwjSVW7uAPKFrOUkhEh7QNU+4QYshoCJwJnAqUx+Oco2e+GtBciB+NOiw2aIk9+C/IkXbhGGbAZ2Qab1O8NwPdIpHeCR0cZME5x12G22BrMMn/P078h4orTwGUxxpQVuijBcz2c5oQfVJkH4elWv1OA6TH79oywsx8m/0gUZUrwDA9HT0A5ckjpldIICY5GAn8QDGNnWb/LEe/SGckDUDJKgKWK48stjrB4lUCrLMYXie74J6Aj8JPiLPXIaYC4QXsiyoFbkCUchu8x0WbXEM79BFdLGG+H0A6TqLjwkaX44xjyipGl3xOZlChMtuTPDuFcgVlZ3WLIzAoHKeErHW0p5LDahkxUYwcnVzREok7tPl0H8d7I0t+IHNqJ4VDMqbzE0V6sFFeQfUaYLXSxZa+Q9uWYbRVZgImbRV0JNFHKn3O0b1aKi5GVsrPQEnmy65QtLoxHBt8MCaETwQRkVi/3cF5QnFFJKXVAR4NvRPD6K96TUQLjroDf1d+OHs44pXQ4UsZKMhJLIcmVjkAfjeB3UH9/TcqAkzHJhi/jehhzUg9NSjlSCNFyx0dwW2My0LKkDChAavg6zO0UwksheX8aiQmSOhC/UzJH419ZXTBeYkpCuv9Dc+BTJXych1cE/KJ4Jyeg9xiM+42qAD+ruFOR6DFx6Hx/Lf7a/B2K90ECOicpWfdE8EqQ4ux2oG0CekMxVRl0l4ezF8Zfn5eDrlMx2WRUtedB/OlyYuiGSYt9tbhBmMCp0Q7oqY+J/4dFcLsgUeg/hJ9PiWAPpASl64CLkYDDhabIVkkDb5F96VrHHhs8OkDOpiWYHGCnvSnqgSk2/A0sU/9PyuClkMrQSoKZ2ePEn4SxGX1XIFFdZv9WGA+hrx+AY+MPKxolyOlaqRR8gyy5VohXuM3ididYvZ0GXIUphk7C/zQbY558BbKN7ELJbKVDY7S6Pw84G3kXoQurD+NPr2PhAkzevhnJ2YscvFLgRcwkLQUustqPw2yHFUpOG6u9JfI9gHaf6zEutAC4xGqrRMLuUuQhDMF4pPpIQWWbZUevHRg3rTDuJ4086UMcvGLgTkztb5P67UpVSxG3aC/XdZiJsWsJrnd9DZCKkn5v4NPVCVktWuYEskiP+1lGrUfq8K6IrjfB8tOLRFd3C5AiyKtIxqYNXI1MeE+iz4l9gZcIrrbeDl4RkpfoCVtBhEsuRN7kaKMm486nm2DKz/pMOD5E5jRgEZJFurZOE9wBVZHqs4jwEtzxSre24xXchZi2wCcW715CQnQ9+K1IOulCa+BbgqvD98Ts19+L1aB8sXyh4iy2+n3u4aeUDfqzmvm4C6EFSCyhX7COyST0xRx0J4Yoa4yctmnE9cR5pa2fpD0g10S4Bq55rpWTif0x3wvMJTzwOheZhErErQNycuoy0mCPkucVZwHZJxq+ichl4DaaYtzgRA9vDCZeSIF5kfAd4elrL8XZSLxvfsLgmohcB26jLZIQpQl/gVIHKfCkUS5Su7shHsH63f9NORhnQ0/EQnXlOnAbwxBbZ3k4dyvOY2BC2rBvc7pi3EjYO8F8QgPk44k0ErG6oLPMr1OYDxCXhZC1j30ZOSTzHRWIreCOD8CU9lumMNnT+hCyrqu9n7tt1QZta1hNUI+1PphDKAw6F2jj4eQbShGbl4e0N1Pt5XHSU+3yVidgWHWhXP2NjP9TmO/0ww4MvUW2IlHZ9Iz2fLy3JcP2TByp/q4FeIqqPtl1gXu75Ou9OGMaCxI2jqfq52y78wSsQkp79YqQ6G6AulywlcxwKM33ezm/nInyEvmKWHbH8QLalXT3svILuj7xu5cVE5kV2l3pinqbFAt11SToDGpXuH5Tg6+bxATUoha1qEUtdlf8CyQEXblhMkr1AAAAAElFTkSuQmCC" />
                       
                        </span>
                     
                        <span class="nav-link-text">Students</span>
                    
                    </a>
                
                </li>

{{-- <?php } ?> --}}
                <li class="nav-item">
                    <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                    <a class="nav-link  {{ Request::is('promote_get') ? 'active' : '' }}"
                        href="{{ route('promote_get') }}">
                        <span class="nav-icon">
                            <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAIQElEQVR4nO2be7DVUxTHP/d276070q0QLt2SooThMl6hJJp00VBKVB7jNRiM1/gDfxBNHiNmSgwTypshKY9RKiOjJuSVRknFJaUIpTr3+GPtbe+zz/49zyPhO7Pn/H5rr7332uu3H2utvQ/8j/82WpWgzt2BQUAvYC2wuQRt7FBUAR0C8kYCG4GsShuBc8skl4saoF0pKp4HbANOceiNwFZM53XaChxeCkECUAs8AvwJtACzgS7FbGAV0rGLHPoURf8DOA0YrJ6zwOPFFCAC95P/ERYCFcVqYD+kg5UO/U3V2GKL9pGiveHwdgDuBc5MKUMFcKNKbse+V20uAp7GKOGAlG3FhtZ8C3AP0sEWRbvX4b0Os0akQSOmY+70ClJAj5RtxUYnZNV3h99alWejFzIs70rZVi0wQ6VaJ+8+jwwfUsQpEIZewHyr4blAz3I0bKEWeBhZBDPAO0BDmWWgo0o7EtXE2AbDhsVhwBnAPsWSaAdhDTAd+CRugTbIlqYXsH9DagEeU33LgW8EPAsMt96b2XnN2Vpgb+v9GcRaDcRJGK29D+xfMtHKh+7AAky/+oYxT1JMm8nV3D8B7YClwHJkp0myrdUDW5C+TQxj1NbcwnQylhQXkjuvj0tYfpEq96ZNdM3ZGvX7WwoBS43RzvuohOU3qd8am+gq4J+KBuBE9bxa/Z4DtPbwdgUmq9QYVfHOooDzEVm3AVcoWkfE43TRCbhUpW5RFe9MCgAxa2ciLjnkT4MngYes91uBt8MqrkogRAVwA7KtBCGDrLKfAUOQ0FgUXxSORHwMgOeRhewlxKM8DdgNWK/y+5D71Q+NqjyJAo4ExsfgawCagCcIt8XrESVFQX/lDLAE6aDepWoQo01vbZOB3pgF8xXgq7DKkyhgF+vZZx3WI6am5psIDMO/X28DnorRZjUwQj23QrYyF6MwChgPHIVRwDTgxbAGkijAxkjgXYc2B+hnvd+iUiEYiIklrAF+tPK6IBHoY5BozzJF/xrZIQA+iGogrQLiYBwwlGiLbani8/kb9iJ3HhKQ1bgcsVxBFsnb1PPPwAtJhdWYgywyczx5/TBWWD9Pvlv2F+J7a76ocR2ilCzy9d0daw9kKmWBFUQr2tu3Uo6AUfj3aRfLgI899G7ItgbizLQ4+T8h29x+6n1vJB6YCKVUwExk1Y5ja+hOtCBfezsSUb4soty41NIplFIBs4ETUpSbR4TLWkyU0hLsWuZyqVDKEdAXCbAkaWM7MnLKhlKOgLRx+LLE7zXcr6NX2uoi1D0X2DdFudWUJo6v+5Szm7gjoFn99sYTQU2IFWUuF4Y2wMHq+Ts7wx0BsxCLqz3wIHAlYmykQX+gM8mmWQsm4FEsVCMucp16n2VnuvOtCvG0DlPvK5Ho8G+Is9Ok6CcR7As0A695BNmEnNs1e/Js1APXA20j+OKgLRI71DvLYsRZyoQVagA+J9x0DTOFw9KUGEI/EaOeNOlTPGuLb4taBRwBXIL4650RV9Q9ZAjCFvJN0o7ItGpSdQV9gSrMKNuIODaFIIP05xXgUeTANDWSOkM2Rltlw6zDvhZf0qhvKpQrJvg65qufHsKn8zI4i1WpEGSl6fgfyO2ObIHtrEeCE32QIX5TAJ/2Hj8A1oXI1oiEyTsjW9xaJK7wBv5bJ0NU22MD8vPgu4JSyBQAuNkq7wus9rDyb/bkVwIXIHZC0EK3FZiK8S41dGzi2gDZ8uC7guJTQB3msmWUAnpb5X2CXGfl93byOpF780SnTYhhs92hbwbGWOXvRrb3gm6ruAoYihhJC5BhGKUAkIPNLBLfdzFb5S136HuR+9VXIgZavcVThRhe05D1Q/PeGLdzcWAr4BLgV+t9EvEUMAEzVOssenvMJcsJFr2G3KPtR4k20Y8HflD8GcIX3USwFWB33qWFKWCAxW9fwhhu0QdY9GsseuixtoNemCu7q8m/SZYKtgLsL/KTQwtTQA1mQZpq0acq2i+Y09vWVt2fk++hjsYETed72rJtj9iLXxhcBcxH5t4gcuddmALAHG+tV+Wr1HNW5WkMsuocYdG7IP6JK4uLSmRrzCp+L9IaQuuQW+DbEYMlzpGZxgz12xFxVI7DXKmznSg9FbY49D2BY5E1Yz3BaEHOEAGOBnb1MSVRwLfIl84gw2uNlXcr5itE+fMzMVZhE8b2d60/HUxZAfxu0Tci68ER5N5L9mGJ+q0kXXAmD40EX32vBc4id8E5BIkrHOzwvocMzS9V8g1jfV0ncPgCbwWU1RiImSbH+hjiBix7IBrfQH4cQGMz8LJDuxO5bNlA7knwDMQ07enQbKxVv+494yTY03r+MZArBJXIzW97kVuKCZhEYSjih5/t0G2rUKeDHJ7bMXu564ZfhZjLyxTPN+p9mMM3WeX/gf86TSSu9giqG/QuKglgW3eu9QdyH0Hnu85Tc4Bcr1s8u2K20elphVypKvgCmQK3WI2NCSkXB9oqzAIPePIrkNGjt0x7OD+HXH1x01iLZ5xV/1lphfxTVXC/eq+zKi307N++lerzLkHcY83zPvHjhMMxd50XUMBZw2JVyQYkPvCqJVCTxddNCZvUrrgKcWxQZZvId2X1PM4i21rYvZ/WyD0BvWZtAA5MKFMOTsZ/a3w2uVpdrejuH6mS4GJVxyqHXo3E9HTbGcTAOR9ZJ3oinuAdmCmrzer+BcjzNwZbFW9F/gHW3uGZi/+vdElwqqrDt81WIh3UUzIqfUr+rlIQKpCtKMirakW+UtKgPeH/Zu2O3PtfR36nM0go7aKIOnJQ1oPIIqIVshbsg9xKa0Zsgh92pFD/Y2fEXxS/1z+m22JPAAAAAElFTkSuQmCC" />
                             </span>
                        <span class="nav-link-text">Promote</span>
                    </a>
                </li>



             
                <?php if(session('Role') !=0){ ?>
                 <li class="nav-item">
                    <a class="nav-link  {{Request::is('question')  ? 'active' : '' }}"
                       href="{{ route('question.index') }}">
                        <span class="nav-icon">
                             <img width="23px" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAJ5UlEQVR4nNWbfYwU5R3HP8/cHdzd7vF+FrTxpb7jW4VqObjd2yZoRfGlNBTUIlaptGk0WhO0qbapIQ1NGxOapo1Gq1DfmkoDmFitiNzuXSy1ClVOqwEUlQLFu+Pk9o7dY+bpH8/OzbO7M7OzO7uA32Sy88z8Xp7nN8/z+z2/38wKvoBobz80sb6+fqZliTNBTpCSrBD8T0r5aTab3bZ16+TPg8oStexoNdHWJpvq64eWAjcLIWcDhgdpVko2g1jX19e8tqdHZP3kfgEMIEVHx9AyKeVDwNQymT8EHkgmI8+BsNwITmgDJBKfTzFN41khmBtOktxgmkeWdHe3Hi68c8IaIB4fPgPMl4GzqyTyHcuqm9/V1fSxfvGENEAi8fkUKY0uKTm3yqLfzWQybbqT9HIkxxFSWJbxTMDBDwH7gHRA4dPHjh2zFuTogz/hDBCLDd0OXOFDsh+43zDMs5PJaCSZjJ6cTEZaTNM6D8QDKIP4QFzf0ZFePNqqRqerhbY22dTQkN4FTPMgWWOaw3e6OTMbc+f2jR8ZGfM7Kfmuj6oPe3sj5/X0iGx9qB5XGbk47zp4KXk4lYreq1+bOVM2NzUdmWKajQdff10MA2zaNGkA5C2x2FC/EPJOD1VnTJ48tAR4/ERbAjd7XN88dWpkhd2IxdIz4vHBlyKR9IBhmHsaGtID8fjgxjlzDl+gKIScOrX5HpCve6uS34YTaAkkEv0TLKuhj+I+Scvi0q6u6L8BYrHBbwrBeqCxWIoYFMK8urNzXAqgvX3o64Zh/cNDZcY0h1trZYBxwEXAV4AmYDzK4aaBvcAB4D2g32ZIJAbnWhavuMjamkxGZ4HKAQyjficwyUf33nQ6cs6bb4ohgHh8cBvwVTdCw+CKavmAZmAesACYBZxB6dk1DHQAbwDkEpsiIinlq06H627Cf/AApzQ3pxcATwEIwWtSuhvANMVZYX3ADOBZ4CDwPHAT6qkHmVlNwBy7IaV0HZhhGHscGjEzSKeEYJTOsvjEm1JOrHQGtAEPop66G0ZQU7wHOAwMABZqaZwCnIRaBn+yGQwDUxZPACzL2asI4TJFHPQCY4AWwNR4XJMgG+UaoAX4NXAHxU/5XdQs2Ai8jTJCYEgpBtyWgBDyNI3qLRC3ubD/vbc3cm1r66Fmy2rYAPKf2r3TvbWK/nIMkACeKBBoAX8BfgVsK0NWEQzDet+y3FaOTDg0R5+2rIZfAJMLiF7L5f3ZK6+UV2ezzgwA70yyrk7uDBoFbgMeIX/GbADuB/4TUIYvch7+IFBXfFfMSCYj28A9DErJHssSs7u7I//VuRKJoVmWZXntBTKmOdwaxAneBzyGM/hDwHLgBqo0eICurgn9UpJyvytXgzQAUqnoy4ZBm5S8BBwFEIJpdXXWDwu5LEsu8VG5ubu79XApA6wEVuGs9+3AhcCjJfgqghDiKY9bsY6O9G/sxpYt0e2pVHTeyEhkHBinGkYkkky2PFjI1NjYvIJcmHXRtg78w9UtwBqtvRkV5wd8R+GNRuCIH8G8eXJsOp3ehYoUbliTyWTu8it6JhL9E6ChccuW6H6AeDx9O8jH8qnk7t7e6Pk9PSLrZYAY8AowNtd+Cbge8C0wemACsB616XkLuA61G3TpvGy0rPROvA0AsA/E76W0/ppKRd8DIUEa8fjguUIYC6WUdwF99fVH51nW+L2WlX4euEYXIAQ3dXZGnwX3GRAB3kHt5kCFtzmotV8Jfgn8RGs/CXzPjTAWO3ynEOK3ZchOo3aULTgPy4aFCsV514WQ6zs7owuU4dwNsBq4K3feC3wN+KiMTumoB/YAJxd0ehpqgzSKgE8/LEqWxC4HfqS1f0zlgwe4ivzBg5phCwsJTXPw+9R28G+DcVWh/yg0wEqcOPwa2la1QtyqnX+qnectgURCNgoh7gupyw8vZjKZWDLZXJQX6Aa4BGfXZAI/wG1vGhyTgfla+0YcJ9oOTtFTyvRCavL05W4p5Y3JZGS+V+TQDXAvjk9YD3wQUvsSHAfUDXQBLxbct3E0pC4dGeBvIJb19kbPT6VanrMdnhvsAbegUlq7w7MBn3JSIGxHzSqAZcDjqFC6PndtL3AaucwtHj+8CMSlFerql1IM1NXJnSMjw1v9iqZeWICa7hIVAsNipiZvEJUGg4oK+7R7fuXvYwJ7CVyrXdtYBbm6k3sesNffUeAZD7rjik9wnsqcErSlMAb4TJPXUXD/Qu3eMGqnGAatwN2oEF4RxmsdylJ+kaQQizV5u3HfbP1Lo1keUt/GnJwhStcLi2AA52jtXYT3yPq0/iPuofRJD/pKMCX32wRcUImAm3GexvoStKXwZZQBJcq7n+pBNwmVGdp6zw+h8zlNjl/+7woDmKi1S7xYLIlbcXaSm4CPPej6yHe2t3rQBcF+7byiJdCgtStJd20IYKnWfqIEvb4MllK579FfjUfKZS40QJj13wGclTsfQNUM/fAyTn7wJeDKCvWG6r9Bfvna5X1bYOjO7ClUiPODCTztwV8O9ApxXyUCFuI4kRcq7EQUld/bcgK9wUFFICvHk8Hx6OVgg6b3W+UyG+Tn+z4vEXyxGGUEgB3AmwH5PgC25s7H5OSUC/17gs8q4KcVx4JDFJeWgqBbk3F3mbzLNd6ghrPRhJo5dtiteFe5S+tEogRtIc7VeEdQ03piGcfp5O8JLi5Dd4fGt6PMfufhEU3QyjJ5V2m81TgeLkP3TzW+x0rQ+uI7mqBy0uF6VF5fTQMcID+0+WGHxndjGf0uwgTUhsIWFg/Id43GM4IKQ5UeWU3WDQF0xzT6Qyh/EAqPagL/HJBnncazKqT+lZqsIDnJ0xr9H0LqBlT5Sn+a00vQT6Z6CQ2oXaS9JxjB/8vw6eTPmMtC6h7FJk3oqyVo79Zou6ukP6XJvMeH7lWNrhoVrFFcjLK+LXyRD+12jW5ZlfTfpsn0csaLyJ+pYWdeEVZrCnqBM11ovIqeYVG4pZ7hQqNXk0KvfbfvA36Ok6VNQjmkaAHNN7TzdThFz7AYzMmz4bYpO6idN1dJbxEuR2VztqVfJD/MTEcVIvZT2lmWC1v2Adynd7vWLxP1QWZNsERTJIFO8qe6gev3PFVBHf6f8r9AjZxgIR4i3whv4Hw3cDxxEerp2/1qr6WyFTjxWaLW+x21VBgQa3H61FVrZcvJ33hI1DQsJ3OrNgqzyPn+5OFxGaqAoRvBLmvNqrVyD+gh+22OwV+AoqicQV9/9vE+8DPUq7XQiUlAnIRaknYfbilXQKX/F7gIlbxc53H/KGontwe1merL/dYCC3FqkB8B56GqRMcEl6Pe+x+iujWBMIffn6VqhiZUUeUJ1CfybkvkWB1++UsRavmXmUtQBddJ2lFrbCN4LQOA/wNMrM/TUqFFmAAAAABJRU5ErkJggg==" />
                         </span>
                        <span class="nav-link-text">Question</span>
                    </a>
                    <!--//nav-link-->
                </li>
                  <!--//nav-item-->
                <li class="nav-item has-submenu">
                    <a class="nav-link submenu-toggle
                    <?php if(Request::is('category') || Request::is('exam') || Request::is('exammanagement') || Request::is('checkquestion') ||  Request::is('uploadcsv')){ ?>
                        active collapsed"
                        href="#" data-bs-toggle="collapse" data-bs-target="#submenu-3" aria-expanded="true"
                        aria-controls="submenu-1">
                        
                        <?php }else{ ?>
                        collapse collapsed" href="#" data-bs-toggle="collapse"
                        data-bs-target="#submenu-3" aria-expanded="false" aria-controls="submenu-1">
                        <?php } ?>
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAABmJLR0QA/wD/AP+gvaeTAAAKAklEQVR4nO2cfZBWVR3HP8+zy7LL7hoib6shgkGs0SaQYWhCluS0FhXSy1QWZvbeFGT5Ms1YQ1Y2NWov9mIpk71NgjWQmk6gjJkaKqu8gyAloCiMqAjCurc/vudw7nOf+7zdt12b5ztz5+6ec+/5nXvuOb/f73x/v/tAHXXUUUcdddRRx6sSuX6W3wB0AdOBCcDJ5jgGaDeHB7wIvAA8DzwObDXHA8CjwCtZd7w/cTzwJeDvaEC8mMfzwB3AF4GODJ8DyG4GNgHzgIuBM4G8r24zcB+wHs2ux4F9uFkHbjYOw83STmAGMNHXVh9wL/AL4M/AkVSeJkO0A1cAu3Az5gBwC/AhYGQCMkYBHwGWAC/55OwELgPaEpCRORqBzwJP4R7oEWA+0Jqi3FbgQmCNT+5uNPMbU5SbKE4FenAPsAqYVeGeHBrcUwLlt6PB8C/5McCnqDwgb0fL2fZjDfCmyt3vPzQA3wQOow5vBt5X5b2d5p7bAuW3AQ9TOIA3mGvPrrLtDwBbzD0vI5XSUOW9mWEosoQecil+BLSUuPZEYDuwwFeWAy4CplQhqxO4BBkmiw8Dm4A3lLinBbjG9M2+qNdUISsTvA7YiNM3MytcfzKwH/h2gn1YgGb+WytcNwunlzeYvvQrXo+snYeW2piQa2YC786gL4MD/5+GXKYgTkQGzVrqiSHXZIJJOPfkTmBIiet2AYfIXu/sLCO3FbiLfhzEEUiPeUj3ldJ3AN3AB7PoVADzgE+WqW/BDeJW4LgsOgVS3vcYwfcBzYH6Vgauz5UP/N8C3I+eZQUwKItO/NAI/A8wOlDXgJbsg1l0pEbcilZN0JHvAJ5Ez/T9tDtxJnIFDgNvDqnPAUuBnyUgaxhiaDrRdi3urL4eWE2xsQGxQUeAXipb8shoxjmk30qp/YuAvyIyIci6HAD+ASxEg5s0Fhk5Gwkf5NhYaAT0UKwrgrqlVnyUwn2zB+xFu5n1pq6PwsG8nGR1bROw1rT/lQTbBURwPmsaPzdQdxZwEO1Pa0UO+AluYB4ALgBOCLn2OOD9wN9wO4qVRCMnuoEdFO/Ru027exCTlBguNw3fHVJ3GlLCUVyVK3GMczmXI4hZyIhZN6pWXnMe2hd3h9StMu1eWmObJdEAPGEaPSepRhGV34uU92xfeRvamq0EtqFlvBTNPv9Ajcc58vMT7Ne7TJvbiK+aADett5Asg32raddvsV+LM1RhxxIKSYS5OEc4KeQRKx6mriLhZtPY1wPlk9DyjYJ2tM3yTDsWdvmsRYz1JGAq8DWcZV7kuz6HWx3VMDlhGE+xzr3MtLk4YptHkUcK1UPEgR+b0SBEMfl2mTzhK5vmKwujmmbirLPf+i425R+P0I88CkptC5SfYtp8igqrrpIbMA23790UqLsSxTRerrKzfpxkzsOQc4uRAxqQ/SH33AM8jZzqDuC/pnyPOQd3RdWgD/hxiLz1yEqPRSvgoVINVBrA0815RUjd76vrYyhGmXM7ekl+rClxTw432/0PbANTByL25YoS5SuQcTqdGANoYxSP1d6vsrgB+XNh2FKifC5ivrejZWdh+7ghma4dhX3mYJymJlil/g5fWSPyw5pC70gHc9AM81BQ3mKqKdtHMStUC3KIWffjHEr7vlVjq2nET33PN2UL4zRcJdqAX+PcmJ/ilHoz8E9TflVMOZ+h2BBNwLlvkWEt8Ahf2TjgRgrdjzQwHecTvoT2p3bw2hHpYB/wmJiypqFUky5f2UjT/tNxGra+WirsRBnM9sn+N4Uvyz+we4ipo8pgsJFxKE4jB00jcfRLrRiNfD0P5bhY5qcZEZ69pu5+nDuUBhIZwN2mEb+PlSehPWIJWMb7LlxAqBktMQ8N4HdJn35PZAlvMI10+sp6KO2rJQEbrPLHl3+Fi6C9JSW5t1OYGWGNyOZyN1WaSc+Ys38GPmmONNCGlmUvcqEAjgU+Ycpmk168ZTSFzznOnHeVu6nSAD5qzv6NejdwXk1dqx42tvwCevugmO0gRLauS0kuyKf074psmkhZmZV2Io+Yc1Smo1b0mXMzMiCg/SjIsKQJL/D/G8051kubQrgeaMZN8SQxlNJc4F9SkGcxjmJXbYeRO7XcjZUI0jzSdx3AZNzb+C3KCp2MolhJYRCl2eUdyBInjUmIf7wJRQVBy3ctorOOp3h2HkWlJdyHmOPPA+fjBvAOpPDLKtgIOAL8Eu2zpyOl/izy+Q4mLMtiN7CMQsZpjjlb1ykWzjaNrCebpPRzcRlf9ngG5QBmgTwiWD0KYzWR0YB0oEd61teiC7eF24Rm/2M4B/qslOWDXqCH4iKJbRg+jUsmCmIOcC3J0Fs3GTk34jqfA6425csTkAHq63XAe0PqbF71NxKSBchC2RBicFovR7oyyKdFgZ1twWDVeFOelM6diPq8LFD+Htz2LdHAOrhZuJlCcmEExbR8VDxsZLwtUD7JlO9ISA7IPRnu+38w0vMe8OUE5RxFHkdgLqpwbVRciyMShpqyVvTVkQf8LiW5IILCGsvU2PYu5GocBs4IqW9GAZhrIrY/BllcSyNtwlH5L1JIatSK64E/lKibgYxUL3KfUsUC9EC7USaBH9Y3XBKj/U7kk9kEImu8ogbxLR5C7lEwZ/oEnH6PGxqoGn80Ah+kODsqqZSzYYhtHlHpwirRTHFfhyDG26qNzFKT23AK/+6Qjg0EzKV8bssQNNNtXCWNpM2yGI5zO1aRgtmPgQaUMVGKt2xF2a4eynBIwgWLhFE409+D/LWBgvPQB4dBnIT7mrNfB89iOFrGNvEnkZSwGrHIyK4UZHonLlS7jgH0wpsQi+Ih6xm2RSqHRuCrVOemTEUUvx+XolhK0CuwGIKSiGye9TLix5ITRxPuNxBqZbAt4/MbX1keLbXgJ7B3mmsnVNFuDqXz2oTJQ2iPm2ZUMTLsPjJKtmgj+qrcvwTzKKQQHMBTEelajlrLodyWf+F8ydWIAB6wuAV19Op+7EM7YpWtd+AhS3whA/Ajaz8m475gqkYx59CyHVXpwirQAXwMcYc2k8JDWfyXUPor0kSQlOf9PbTkFlOcLhvEWJRxZVPmNqLdwFrz907cJ7LPmT62obTfY5HbYX/25AwKM8deQR7Bz9F2sjfeY2WDC9Ab348LQYYhh/ScNTR7ccRBnOM5pCc/RzIzOlN04Qak3JdKMxAhYB/6T7g97lj0wxDfQSlrq9EM3IfcjsPm7+3IWV+K9OzFRv6AtKjVYAwudnpziWsm4IyLZXrPz6R3AxwjcT80cS/F6W9TUOzY/gRKL8o0GE4dtCBuzUN+mmWORwNfQDksfh21nAH+gzdZ4wdoYA6gTwSuQzsG/+eovUhXpc7uvhphs0fDjnXoY+ywnz/5v0SUTAMPOax7kVHoQZZzJcnmydRRRx111FFHHXXUkR7+B3+RvwEHQ5sxAAAAAElFTkSuQmCC" />
                        </span>
                        <span class="nav-link-text">Exam Management</span>
                        <span class="submenu-arrow">
                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down"
                                fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z">
                                </path>
                            </svg>
                        </span>
                    </a>
                    
                    
                    <div id="submenu-3" data-bs-parent="#menu-accordion"
                    class="
                    <?php if(Request::is('category') || Request::is('exam') ||  Request::is('exammanagement') ||  Request::is('getcattime') || Request::is('searchexam') || request::is('checkquestion')){ ?>
                        collapse show
                        <?php  }else{ ?>
                            collapse 
                            <?php  } ?> "
                        style="">
                        <ul class="submenu-list list-unstyled">
                          <li class="submenu-item">
                                <a class="submenu-link  {{ Request::is('category') ? 'active' : '' }}"
                                    href="{{ route('category.index') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAABmJLR0QA/wD/AP+gvaeTAAAKAklEQVR4nO2cfZBWVR3HP8+zy7LL7hoib6shgkGs0SaQYWhCluS0FhXSy1QWZvbeFGT5Ms1YQ1Y2NWov9mIpk71NgjWQmk6gjJkaKqu8gyAloCiMqAjCurc/vudw7nOf+7zdt12b5ztz5+6ec+/5nXvuOb/f73x/v/tAHXXUUUcdddRRx6sSuX6W3wB0AdOBCcDJ5jgGaDeHB7wIvAA8DzwObDXHA8CjwCtZd7w/cTzwJeDvaEC8mMfzwB3AF4GODJ8DyG4GNgHzgIuBM4G8r24zcB+wHs2ux4F9uFkHbjYOw83STmAGMNHXVh9wL/AL4M/AkVSeJkO0A1cAu3Az5gBwC/AhYGQCMkYBHwGWAC/55OwELgPaEpCRORqBzwJP4R7oEWA+0Jqi3FbgQmCNT+5uNPMbU5SbKE4FenAPsAqYVeGeHBrcUwLlt6PB8C/5McCnqDwgb0fL2fZjDfCmyt3vPzQA3wQOow5vBt5X5b2d5p7bAuW3AQ9TOIA3mGvPrrLtDwBbzD0vI5XSUOW9mWEosoQecil+BLSUuPZEYDuwwFeWAy4CplQhqxO4BBkmiw8Dm4A3lLinBbjG9M2+qNdUISsTvA7YiNM3MytcfzKwH/h2gn1YgGb+WytcNwunlzeYvvQrXo+snYeW2piQa2YC786gL4MD/5+GXKYgTkQGzVrqiSHXZIJJOPfkTmBIiet2AYfIXu/sLCO3FbiLfhzEEUiPeUj3ldJ3AN3AB7PoVADzgE+WqW/BDeJW4LgsOgVS3vcYwfcBzYH6Vgauz5UP/N8C3I+eZQUwKItO/NAI/A8wOlDXgJbsg1l0pEbcilZN0JHvAJ5Ez/T9tDtxJnIFDgNvDqnPAUuBnyUgaxhiaDrRdi3urL4eWE2xsQGxQUeAXipb8shoxjmk30qp/YuAvyIyIci6HAD+ASxEg5s0Fhk5Gwkf5NhYaAT0UKwrgrqlVnyUwn2zB+xFu5n1pq6PwsG8nGR1bROw1rT/lQTbBURwPmsaPzdQdxZwEO1Pa0UO+AluYB4ALgBOCLn2OOD9wN9wO4qVRCMnuoEdFO/Ru027exCTlBguNw3fHVJ3GlLCUVyVK3GMczmXI4hZyIhZN6pWXnMe2hd3h9StMu1eWmObJdEAPGEaPSepRhGV34uU92xfeRvamq0EtqFlvBTNPv9Ajcc58vMT7Ne7TJvbiK+aADett5Asg32raddvsV+LM1RhxxIKSYS5OEc4KeQRKx6mriLhZtPY1wPlk9DyjYJ2tM3yTDsWdvmsRYz1JGAq8DWcZV7kuz6HWx3VMDlhGE+xzr3MtLk4YptHkUcK1UPEgR+b0SBEMfl2mTzhK5vmKwujmmbirLPf+i425R+P0I88CkptC5SfYtp8igqrrpIbMA23790UqLsSxTRerrKzfpxkzsOQc4uRAxqQ/SH33AM8jZzqDuC/pnyPOQd3RdWgD/hxiLz1yEqPRSvgoVINVBrA0815RUjd76vrYyhGmXM7ekl+rClxTw432/0PbANTByL25YoS5SuQcTqdGANoYxSP1d6vsrgB+XNh2FKifC5ivrejZWdh+7ghma4dhX3mYJymJlil/g5fWSPyw5pC70gHc9AM81BQ3mKqKdtHMStUC3KIWffjHEr7vlVjq2nET33PN2UL4zRcJdqAX+PcmJ/ilHoz8E9TflVMOZ+h2BBNwLlvkWEt8Ahf2TjgRgrdjzQwHecTvoT2p3bw2hHpYB/wmJiypqFUky5f2UjT/tNxGra+WirsRBnM9sn+N4Uvyz+we4ipo8pgsJFxKE4jB00jcfRLrRiNfD0P5bhY5qcZEZ69pu5+nDuUBhIZwN2mEb+PlSehPWIJWMb7LlxAqBktMQ8N4HdJn35PZAlvMI10+sp6KO2rJQEbrPLHl3+Fi6C9JSW5t1OYGWGNyOZyN1WaSc+Ys38GPmmONNCGlmUvcqEAjgU+Ycpmk168ZTSFzznOnHeVu6nSAD5qzv6NejdwXk1dqx42tvwCevugmO0gRLauS0kuyKf074psmkhZmZV2Io+Yc1Smo1b0mXMzMiCg/SjIsKQJL/D/G8051kubQrgeaMZN8SQxlNJc4F9SkGcxjmJXbYeRO7XcjZUI0jzSdx3AZNzb+C3KCp2MolhJYRCl2eUdyBInjUmIf7wJRQVBy3ctorOOp3h2HkWlJdyHmOPPA+fjBvAOpPDLKtgIOAL8Eu2zpyOl/izy+Q4mLMtiN7CMQsZpjjlb1ykWzjaNrCebpPRzcRlf9ngG5QBmgTwiWD0KYzWR0YB0oEd61teiC7eF24Rm/2M4B/qslOWDXqCH4iKJbRg+jUsmCmIOcC3J0Fs3GTk34jqfA6425csTkAHq63XAe0PqbF71NxKSBchC2RBicFovR7oyyKdFgZ1twWDVeFOelM6diPq8LFD+Htz2LdHAOrhZuJlCcmEExbR8VDxsZLwtUD7JlO9ISA7IPRnu+38w0vMe8OUE5RxFHkdgLqpwbVRciyMShpqyVvTVkQf8LiW5IILCGsvU2PYu5GocBs4IqW9GAZhrIrY/BllcSyNtwlH5L1JIatSK64E/lKibgYxUL3KfUsUC9EC7USaBH9Y3XBKj/U7kk9kEImu8ogbxLR5C7lEwZ/oEnH6PGxqoGn80Ah+kODsqqZSzYYhtHlHpwirRTHFfhyDG26qNzFKT23AK/+6Qjg0EzKV8bssQNNNtXCWNpM2yGI5zO1aRgtmPgQaUMVGKt2xF2a4eynBIwgWLhFE409+D/LWBgvPQB4dBnIT7mrNfB89iOFrGNvEnkZSwGrHIyK4UZHonLlS7jgH0wpsQi+Ih6xm2RSqHRuCrVOemTEUUvx+XolhK0CuwGIKSiGye9TLix5ITRxPuNxBqZbAt4/MbX1keLbXgJ7B3mmsnVNFuDqXz2oTJQ2iPm2ZUMTLsPjJKtmgj+qrcvwTzKKQQHMBTEelajlrLodyWf+F8ydWIAB6wuAV19Op+7EM7YpWtd+AhS3whA/Ajaz8m475gqkYx59CyHVXpwirQAXwMcYc2k8JDWfyXUPor0kSQlOf9PbTkFlOcLhvEWJRxZVPmNqLdwFrz907cJ7LPmT62obTfY5HbYX/25AwKM8deQR7Bz9F2sjfeY2WDC9Ab348LQYYhh/ScNTR7ccRBnOM5pCc/RzIzOlN04Qak3JdKMxAhYB/6T7g97lj0wxDfQSlrq9EM3IfcjsPm7+3IWV+K9OzFRv6AtKjVYAwudnpziWsm4IyLZXrPz6R3AxwjcT80cS/F6W9TUOzY/gRKL8o0GE4dtCBuzUN+mmWORwNfQDksfh21nAH+gzdZ4wdoYA6gTwSuQzsG/+eovUhXpc7uvhphs0fDjnXoY+ywnz/5v0SUTAMPOax7kVHoQZZzJcnmydRRRx111FFHHXXUkR7+B3+RvwEHQ5sxAAAAAElFTkSuQmCC" />
                                    Exam category
                                </a>
                            </li>
                            <!--checkquestion-->
                            
                            <li class="submenu-item">
                                
                                 <a class="submenu-link <?php if(Request::is('exam') || Request::is('checkquestion')){
                                   echo "active"; 
                                }else{
                                    echo "";
                                }
                                
                                ?>"
                                
                                
                                    href="{{ route('exam') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAABmJLR0QA/wD/AP+gvaeTAAADC0lEQVR4nO2av2sUQRTHPxevSKMoYkLAwsLGQhHUKBG1CPFHI4hgKYhg6d/iH5FOCwuJImjhJfESFNGAglhbiigqGEws9i03d+TudndmM2/u3geWuZ2defvu7bzv7M4uGIZhGIZhGIax62wr2j4BM/X+3fDEDlryQcwdj02yQdQWwA2nnIrqUUH6BXAFaEXwY4rEgtgvgC3gVSQ/kgqithTOOQR8IAFN1BpASCSI2jSwF/XprFEDe1EdRM0p7KI2nVMJICgNonYN7EVdOqeggb2oCqK2FK6ybficuOHTmU7wfO344nsRo/mvRQOr4p1BE4Ec6WULHamtHi0aWBW1I3BsqCuAqWigN1o1cA/ZBXgexh291KWBtx3bR2qwnxNdw+twoAF8dGzfCmzfRe0k4qOBC8AxZ3/W35360KiB96V8K+UZf3f0EjqFjwL/gL/ACbIL8QtoBjyHy8hp4AOxtyj7n2X/eMBzuKgNYBUNnAS+ib3TUrco+3dL2FkDXhdsq3YSqaKB14EDQBt4I3VtKc+XsDMLnCt57miETIElsXXPqTspdV9q8kltCpdlGtgEfgP7nfoJOml9uAaf1KZwWQ28QTbTPgG+O/VbwLL8vtinb4vuFeYct66253ItGnhTykc7HMvfrVzy8EftkluIFD5Ilr5/gL07HD9L51VkaJ9GQgPviI3HfY43gZ9ko3o6sE9qA1hGAx/SrVeDtiILCyMxiRTVwCYwX8Lu1QJtlkloMdf3Cs5J/3dD2uX3g18J+wpS7QgsyhUpXwxp954seDNkiwxqiH0fuCDlyyHttoFn8vtaVafqIKYGTgKnyG5hinxH81RKVQH0xUdDLkjf9YLt95GtE27S/bjnQ9IaOCdl0aWnH9K27MxdKzE1MF9yWithd0lKNWkcUwPzALYHtuom18HLpT1Sio+GrNBZaSlKA1il3KgdhNpHuVRQO4nYtzGe2PeBBbEUDuTI2GIa6IlpYGRMAwM5MraYBnpiGhgZ08BAjowtob78THkUemEj0DAMwzAMwzCM3ec/446WDpkEF6IAAAAASUVORK5CYII=" />
                                    Question Uploads</a>
                            </li>
                            <!--searchexam-->
                            <li class="submenu-item">
                                <a class="submenu-link <?php if(Request::is('exammanagement') || Request::is('searchexam')){
                                   echo "active"; 
                                }else{
                                    echo "";
                                }
                                
                                ?>"
                                    href="{{ route('exammanagement.index') }}">
                                    <img width="23px"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAABmJLR0QA/wD/AP+gvaeTAAADO0lEQVR4nO2bv24TQRCHvyDkFCQSEiENPAE1LQpBoYAGJcprgEARCqECEhDPkgYELaJBkZIIAlRpoKMPcaAACUwxezrruD9rz57v1p5PWp3v/LvzeDzenZ29A8MwDMMwDMMwGmUe2AQ+Aj9cOwCeAOcbtCsKVoEu0Ctox8BKY9a1nFXgL+KoF8ACcMa1q8BL994fYLkhG1vLPGnk3S/RrTvNd2BuBHZFwyZp5FXxymkf12pRZHxCnLLgoV102oNaLYqME8QpMx7aWaft1mrRiDmlPL83gHZqiHNaj9aBX932soc20XxRfmar0Drwtdve9dDey5xjIDOMY+RvuV6i23CaI+DcCOyKihUkSe4hqcoiMqjMANeQiEsS6VsN2dh6lpEkuWgqd4Q5r5I5JEn+gKQ3XeA98Aj72xpGS5gGbgO7SL0v29cdAp0+fccdK+obNe0XsA/cLLA1xGcE5QLp3Les9acz6x76EC3Pia1y4DSp8w6REXU2o1ly758AF11L5spLIY1xdIAH7vp7NVw/KHdInXe2RLftdNuZ13URTYFiDzG0Kpfrj7r+aKyDDvCQ4gjcAd4p9r047am75LZvK3TfgC3gudvfcsf6Cd0595BcM0uyzDDsflAG6VSTkTc7ImevFWIU3gVuDPOFQuEbgXnsIL/alczx30iqk7wuYqrkvWjQOLAs5N8orjuWhMyLaklSm0JbUJ14NA4catgfNzQOrHXYjwXfkTBxVIiR0+daRT9M9py6f8DK72t9oJI68sCQVK0lN55LWh84IkadB/rW57QFA3VBIfY+UFswGFlBIS8Chs0DbSbisD5wAGwuXIBvBCZlqaS+N40sGJXdD2P0sY9EzQZyz0tSSh8mksYqAn25TtrnaZf+JtKBIGuve8BP5P4XcyC6qVBeUcBnymXFBCNFU0woI9QN5WNdTDBovwOrBhwrJiiJppiQR150ZI/5aKIm9ghsHHOgEnOgEnOgEnOgEnOgkrqmclqsmDAptDUCE8a6mJC3TgJy7/IgmqjROPCz264h6yRrmeO+mjLGupiQPFrwDHke5Cn/P3Lgo9EQdTEB0nWSE4ofOfDRGIZhGIZhGIYxSfwDrsahyU2qxIUAAAAASUVORK5CYII=" />
                                    Today Exam ?
                                </a>
                            </li>           
                            
                        </ul>
                    </div>
                </li>
                
                <?php } ?>
                <?php if(session('Role') == 0){ ?>
                    <li class="nav-item">
                        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                        <a class="nav-link {{ Request::is('settime') ? 'active' : '' }}"
                        href="{{ route('settime') }}">
                            <span class="nav-icon">
                                <img width="23px"
                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAESUlEQVR4nO3bS4gcVRQG4G/MaBJ0VIKa0SQaJQpGHRWMouBj7SJLEzRCNi5ERBeCLlwrgvuso4ILF4KggoLEScxCF8HE+CAiaiYPH3li1JjouDi36bKnuqa6u2qqZfqHy+2+XXX7r/+eOvd0n1OMMEIe1uItnMJxvIlrG2XUGybxBn7CEbyGVWVPXoEZzHa0Q7iqaqY1YAUOmsv/+/TZvHglnTCN68TKT6exV6vnWzmK+L9cZoJd6eAHMmMPpbHdVTKtCUX8d3YefEHOBKdTvyYztjr1v1VAsG4U8T9VZoKtQq3jeD6142nsiWo41ooi/lvKTLDEXAfSakuq51s5euI/1mWS2dRvS/2T8xw/bBiYf0uxbu+HHaX5ZxX5BPeV/IJduD/zfrkINK7GSpxM43+JmGImva4TffHPCtDrCj+Le3CviByLMIsfsR/78EV6/SXO9vi9WYzhLmzEi32cmyvAfPdJnlDnRKR1Wmw1Z8QWu0pYxEr5W+55HBCC7BOiHBDh6685x1+B9bgZG/CwsLosyvIfWIDt+Cy1zxWv5BJcjyncmtptWIfxLuf8KWL5i9P5F+KSnON+wHvKO7rKBMge168PWCpW9BYhyHpxO10jP24/iW/wlbCaD4Tl9M2/m/pl8IxqfMCe1DqxXIjZit7+1o7yWhgTt8LG3um3J8iS7BzLw8gHpH7kA+Y5rgwa9wFNC1CEMj4gi4H5lw13hzUs7ov/ILtA3sS0lS1DpvEfV3meeVGhSgvoXM3GV7cMFr0FjARomkDTqGMXKIvO3aKR3WNkARXO1e+qNLp7jCygxrnz7uVB7vu8eQbGyAJqnLtolYYmalz0FjASoGkCTWMkQNMEmkadu0BZFMUA3eKEURxQFYbBAsqs5iArXvhvcZUCLBMJjztxB67EZbgIEyJxckLkCb8VWaC9ov6wMQwqwCQewSbc3ed8x0RmaW+m7ReZoSIsFcmUDf5bEteJQusZJDHyER7ULjw6Ky5kj8jaHMIv+CN9Pi4yPmtxg8gG3S4/A/QPDot845E0dkJY1KSoWF0n0mVF11TEv5ICiTOipvgdfKi/OsLVImc4JQSZwo3yLy6L8/haCL5buyBqwQR4Gq9rp66q9AHjIrO8Vrs+eQK/46iwrO+0rauIf7ef3pXkBofJB2zO8OrGd877Kn3AOXyauYAZ/KxdGbIMl4s0+U3CWhbCB9QmAJGtfVv4gR3CJ/SKun1AzwKUxVPiQYQ6CqgH8QFlMWehd+peY9vZpnv8soVApfwXTansfF572zyfDzv64r+oyuXzfg4/nvpjeA4viAcO4NGKydaBTv6tByYoyf99odbmzNiWNPZuNRxrRYv/pszYY7rwz7OAidRnQ9SDqb+0AoJ1o8X/cGZsJvWl+LceO9sh9uI12lvMS9VwrBUt/h+LIKtn/gM/eNgwKuE/KaK8o+JW2K6HR0+HAP93/iMsGP4FuTShszie8/cAAAAASUVORK5CYII=" />
                            </span>
                            <span class="nav-link-text">TimeTable</span>
                        </a>
                    </li>



                    <li class="nav-item">
                        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                        <a class="nav-link {{ Request::is('block') ? 'active' : '' }}"
                            href="{{ route('block') }}">
                            <span class="nav-icon">
                             
                                    <img width="23px" src="https://img.icons8.com/ios-filled/50/000000/lock-orientation.png"/>
                                
                                </span>
                            <span class="nav-link-text">Block student&Class</span>
                        </a>
                    </li>

                    <?php } ?>
                <!--//nav-item-->
                <li class="nav-item has-submenu">
                    <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                    <a class="nav-link  {{ Request::is('score') ? 'active' : '' }}" href="{{ route('score') }}">
                        <span class="nav-icon">
                            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAACr0lEQVRoge2Zv2sUQRTHP8lFjYWKJoo/QLSxtRBBizQWARVEsbIQRCwtBEXFv0EQtBBBEALpUkgIphCLRESEKHj4A7SxEANaiD+LaFyLmXAzs7d7M7vz5i6QB8PBvLfvfT87O7szc7Biy8syofYG2JqQQwwkOcxSUYmcSWEkQV7q3yawOXKNwqISOTcCcyQaGUkQUCOxNDKiMNIgoGCaCMOkAIEEMKlAQBgmJQgIwqQGASGYboCAAEy3QCAyjPQSJaQ1y5L2eRT1iQuxOjemUMdAjaRVrcpN6QjfXyFpT1oskBvkn+kTBbF3nLj3wGAkHYXmO9nXA/PYAl+Qf4z2AAtO3JGIOqIkOEd+VEadmAnHPyGgo3aCfuAZttAZw78f+Gf4fgG7BHRESXAQW2wGjGjfI6f/sqCOKAnGsAVPomDcvfpqYR21E2wHfhjXLgD3sUEOJdARJcFVbOFmG0+oo3aCNcA78hDfgW0SOqS+7I2C3GuBLUI1S63qiFzHHgnzTTZL3EWol1UB2Qv8Ma59CzzGBjsTUaOXhYIMoJYmpugLKOFm32dgk2ftdi3YQi+84hT8gJr4DeCV47vtWTs5yG7gp1PwtOE/7vgWgQOBtcVB+oCH2EKb5N9cT5yY56jR8q0tDnKW/PAfbhPnLlUy4HxAbVGQYeCLI26mJP6BE/sNtazxqZ1ssse0IJCVPXuvWa+A3CLsW+HG3uxUINUcaaA2YJ0+fu3803icz6Wc7Oto/Q03h1opt7NB4KmOew1s8Eme+q21A/ioa44VxNzV/nlgp2/ibrx+96FOWDLgouO7pPt/U768yVm3viMnUWuxReCo7hsF/qL2NqdCE5atQCXaJ1qPyzXd9xU4pn8z1HlAsKUGcSewe058rwpEL9gqWgd7s6i9zbK1IWCKDjvK/5Qx6w2h0pvRAAAAAElFTkSuQmCC" />
                        </span>
                        <span class="nav-link-text">Score Download</span>
                    </a>
                 
                </li>

                <li class="nav-item">
                    <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                    <a class="nav-link  {{ Request::is('notice') ? 'active' : '' }}"
                        href="{{ route('notice.index') }}">
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAABmJLR0QA/wD/AP+gvaeTAAAFe0lEQVRogd2aXWxVRRDHfxdqKypFE6iWaAIaJUYwqDyICBrkxX48+IEmWsVg/YhGq09IVDAajfikTwQlGqVGHjQQSkxUFEP6IoIPUj+qQQk0StSXYost0nt9mNmccw979p7Pe1r/yc295+zs7Mzd2dmZ2YX/F1qBbmAnMAT8AxwA1gKlAuXKDCXgGuB5YD9QBiohn3eZokrPANqAzcAxqpUaBXYBDwPzgHOALmBY2x8oQN5E8JvqKNVKDgFbgA7kz7DhPqXdn7ukCeEy1TKyLjcC1xHNTJu170gewiZFVFOdm4D3POXzWyaSpkBaU42Kh5TnzpR8EuEqYB3QD0xQreR3wKvAjWTrUfuU/4MZ8gxFnqZqMAfYDtwVMv4osvZbU4zhRL1M1eAV5f2Bpa0Dn4duyGjAErBYmXcCS/BMsgIcRMxqN/CNvssSbyvP1y1tHfrdl3aQepiqC7OBZ4ALHTQlxKIqyDYXG/U21TC0AId03HUOumuV5hgRnWDWAUAW8Ct7CJnpMGxUus0uhmcDq4A3gKNUz+JJ4DOgB7g4peBJMAf4VmX5AbioBv0Bpb3V1rgM+JBiTdWF4My21KCfi1jhCDKJVXiR+gQASRF3ZkEcZgXYEWy4TRvGgefIz6smRdyZNdilfbqDDfu04bGMBMwSSZU10dUElujqhDJszkbGzDCTZMpCILryYxpiylCsQ7JhPrAQGABuAf6I0dcZXZlMYlMa6XLCIuC8BP16gVPAlbbGZdpYRjKOpUmlm0RoxB1yci/wN9629COwnmKCi1zh32NbgaeRKp/xbGXgc6TEuQOJtOqFq5GI76yUfE4BexDHZ8V0JAvajhSyzawPA1uB5eQbjJSA1zizGpLmM4EEUjUFPx+4G1hD9do+DLynnyPp9DsD3cBbwBjwPvBXSn6zEattQk4gImMB8DLVCUUZ2IsUuON60xbgTWBF4P2g8r49Jj8X7sQLS2NjGrK2tlGdaIwga32l0rjgj6C2BNpO6/vGJMKFoFF5/puW0QxgNZIy+nPlIWTNXG7pUysRMDyyhrHIzHAp8ALwC9Um34/UhWcRLTa2KdyBhIkj+t1u6VeLJnOFDUrATcA7eHG6KR6Y+pIrNg4q3IHd87bHpMlNYT/ORQ6y9uBtM0O4E4Ggwl/r83rl96w+fxWTpi4K+7EQUfokYt5hCCpsrMTsAk36PBaTpgKUa3nTLDEAfIk4OtsJQRgG9ftJxNua7K4pJk0huB/5p/sdNMEZbse+PuPS1N2kQdbXCR3YtmWB3Uu3I+txHLsyUWgKURjEe1eAl0Laa+3DtvUZhaYwhW/WwY9gj8hcCjcihcagB45CU5jCJbzgZKWlPSzwGKPaVNti0tTdS/sH3qa/18ToA5Lbmijq4wQ0hWE+3qnAzEDblIml48LUw4N3p/LIlowTS50tpcFaFWJv4L3Jh+/IcKzVyvP7Is+NmoHfkcjrMuBXfd+DnOSPIxWPP0P6m1rVvsD7BuARvDBzAXAPMstPZCR7YvQi//wG37s4Na2fLTxXWOhOI/l5qeiTwVVI8eAwEnn5ndUi5MTBdlK4FFHsI6R840cD8Dhe5fU4YgkDmUmdAtPwamTLY/QzpyWxinKTBebK0daI9P6TwSjnxJMOVyD74zBy3bcWOnGHlk4UEWkF8RMifDNyOF8Lnfqd+t5VkXgUmbVPa9D5710tzluoPDELKf1MAJc46JYgyh4l4XHPZDBpkPXbh8jT5aAzB927ySferivaECUGCZ+9g0pjvXc11TAdubFeAa63tDvvXUXFZDFpkPXbq797LO3dyMx/gru8M6XQincTYZM+XwA8hSQLYbM/pdGF5K22ZGGDo9+Uxg3ITbrjiAf/As9Dp8J/5iIogEimxqoAAAAASUVORK5CYII=" />
                        </span>
                        <span class="nav-link-text">Notice</span>
                    </a>
                    <!--//nav-link-->
                </li>

                <?php if(session('Role') !=0){ ?>


                <li class="nav-item">
                    <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                    <a class="nav-link {{ Request::is('banner') ? 'active' : '' }}"
                        href="{{ route('banner.index') }}">
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAESUlEQVR4nO3bS4gcVRQG4G/MaBJ0VIKa0SQaJQpGHRWMouBj7SJLEzRCNi5ERBeCLlwrgvuso4ILF4KggoLEScxCF8HE+CAiaiYPH3li1JjouDi36bKnuqa6u2qqZfqHy+2+XXX7r/+eOvd0n1OMMEIe1uItnMJxvIlrG2XUGybxBn7CEbyGVWVPXoEZzHa0Q7iqaqY1YAUOmsv/+/TZvHglnTCN68TKT6exV6vnWzmK+L9cZoJd6eAHMmMPpbHdVTKtCUX8d3YefEHOBKdTvyYztjr1v1VAsG4U8T9VZoKtQq3jeD6142nsiWo41ooi/lvKTLDEXAfSakuq51s5euI/1mWS2dRvS/2T8xw/bBiYf0uxbu+HHaX5ZxX5BPeV/IJduD/zfrkINK7GSpxM43+JmGImva4TffHPCtDrCj+Le3CviByLMIsfsR/78EV6/SXO9vi9WYzhLmzEi32cmyvAfPdJnlDnRKR1Wmw1Z8QWu0pYxEr5W+55HBCC7BOiHBDh6685x1+B9bgZG/CwsLosyvIfWIDt+Cy1zxWv5BJcjyncmtptWIfxLuf8KWL5i9P5F+KSnON+wHvKO7rKBMge168PWCpW9BYhyHpxO10jP24/iW/wlbCaD4Tl9M2/m/pl8IxqfMCe1DqxXIjZit7+1o7yWhgTt8LG3um3J8iS7BzLw8gHpH7kA+Y5rgwa9wFNC1CEMj4gi4H5lw13hzUs7ov/ILtA3sS0lS1DpvEfV3meeVGhSgvoXM3GV7cMFr0FjARomkDTqGMXKIvO3aKR3WNkARXO1e+qNLp7jCygxrnz7uVB7vu8eQbGyAJqnLtolYYmalz0FjASoGkCTWMkQNMEmkadu0BZFMUA3eKEURxQFYbBAsqs5iArXvhvcZUCLBMJjztxB67EZbgIEyJxckLkCb8VWaC9ov6wMQwqwCQewSbc3ed8x0RmaW+m7ReZoSIsFcmUDf5bEteJQusZJDHyER7ULjw6Ky5kj8jaHMIv+CN9Pi4yPmtxg8gG3S4/A/QPDot845E0dkJY1KSoWF0n0mVF11TEv5ICiTOipvgdfKi/OsLVImc4JQSZwo3yLy6L8/haCL5buyBqwQR4Gq9rp66q9AHjIrO8Vrs+eQK/46iwrO+0rauIf7ef3pXkBofJB2zO8OrGd877Kn3AOXyauYAZ/KxdGbIMl4s0+U3CWhbCB9QmAJGtfVv4gR3CJ/SKun1AzwKUxVPiQYQ6CqgH8QFlMWehd+peY9vZpnv8soVApfwXTansfF572zyfDzv64r+oyuXzfg4/nvpjeA4viAcO4NGKydaBTv6tByYoyf99odbmzNiWNPZuNRxrRYv/pszYY7rwz7OAidRnQ9SDqb+0AoJ1o8X/cGZsJvWl+LceO9sh9uI12lvMS9VwrBUt/h+LIKtn/gM/eNgwKuE/KaK8o+JW2K6HR0+HAP93/iMsGP4FuTShszie8/cAAAAASUVORK5CYII=" />
                        </span>
                        <span class="nav-link-text">Banner</span>
                    </a>
                </li>




                <li class="nav-item">
                    <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                    <a class="nav-link  {{ Request::is('management') ? 'active' : '' }}"
                        href="{{ route('management.index') }}">
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAAEaElEQVRoge2YXYhVVRTHf/d6m+nDMsmZnCwk6qUpzCTNmYqKkAzKmvKDAfEjCKYo9SHIHgp6CAwLeiqCinopjCCiIJjCGjAdP0jDKMpEyVLGSp0sHa1p97DWdu/uPXufc8/c6/Rw/nA4h73/+7/X/jhrrb2hQIECBQpACbgNeBH4AhgCTgHfAxPG0a66cA/wNWACz7LxMy0bKsCrOIOPAK8AC4GZQJ+WHwXeAG4fHzPjKAHvIoaeAp4BWqs4FWRr2YH+A7xwFm3MhNWIcX8A3SncDuBx4IS2ebS5ptWiDNyBbJ+dwCFkVu8FflWj7qtDr1fb/AasBT4A9gLHtPzWRhnuoxMYJPnnPanvT3LobgpoWr3pYzXcx1zcNjgMvAQsAGbhZs8AD+bQfljb/gAsB+YgjsFOjgE+BqaNaQRAGxIDDPA2MKmq/k5gWOs7cujP0LbfVJU/BLyGbF8DfEmt86gLz+GWORTIDirnvBz6k3EuOVT/rXLW5NA/gz0qMjvC2a+cthz6F2vb4QhnAW5VcuF8YBQJbKUI7z3t6IEcfXRp268inBbgL32C26scEShpvXWtIWzRd0+EE8JqffdHOKeRf6UCtIdIsYGcBP4ELiWe6N3t8etByWtzfQrX/n+n6+zjDPpJD07HlXNZDv1p2nYowulUzp6YUGxFQFYD3Kwn4Tt9X5OilQTb5kCEY1OY2GCjmIjMxO/I/gzhKeXtJT3P8tGtbQzwZIR3IfA34nhidgRRRvy7Ae4ivHqtwIDyNtShv0HbDBAPdrco7yfi3jOKl3GpQixytyEJ5BDiLtPQgqQ7o8CUCO9yZDUM8GwG3SBagc/IltnapHJFBt2Vyt2cwluqvH6yTVAUa1TsoxSeTcsPEZ/lKbgcqjfCqwC7MvAyow2XGD4W4ZWAjaS7Spv2bCS+59/BOZExr4bFEyr6YQqvHfdPhWDrg1G6ijc3i4FpccRin75HU3iHM+rVwx3MQso6ELu0NwGLgIsCPN+NXplQ75eFXG47cnnRcHQA20k+jvqoIIchW3cUCXRX6LMWF5cM8Dq1AS6pj6fJPuGJmA6s8zr/EXgE+By58vEH0gVs07IR4NOAUUbrRvR7O3Bz1UBGkOPtOiQ2GWAHcrF3bj0D6ALexwUio99Xe5wtWt5D7QXCeuXMxyWdNhbM17r1VW02I2d+gzsWACzxBmOAX4DnSTlWdyCxIjSTq5TXiqxOiPemp9ntlft52FuR9gdwM78wwDmBrFiNW74R+DkibpCz+XLEg8V4A55uj1fuH7xi10AGOT734lY+9Azirc4luEjbiOc4cI5q93nlfVrWghzYGtXfVmBCGdkyU2kcJiIrDO4843/PRu4DGoU5wLIycH8DRS3m6TtpIPNoPJaWgauaILxY30kDWdSE/m4oAxc0Qfha4Dr+6yanIjeLnU3ob3IZyUBDz+4xiC+hdkUWB7hZsJuIrWlHx2PU3veOF4aRm8lEpA3EpNSfbeQ+sxcoUKDA/wv/ArHxj/XR5l5KAAAAAElFTkSuQmCC" />
                        </span>
                        <span class="nav-link-text">User Management</span>
                    </a>
                </li>

                <li class="nav-item">
                    <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                    <a class="nav-link  {{ Request::is('payment') ? 'active' : '' }}"
                        href="{{ route('payment') }}">
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAAEaElEQVRoge2YXYhVVRTHf/d6m+nDMsmZnCwk6qUpzCTNmYqKkAzKmvKDAfEjCKYo9SHIHgp6CAwLeiqCinopjCCiIJjCGjAdP0jDKMpEyVLGSp0sHa1p97DWdu/uPXufc8/c6/Rw/nA4h73/+7/X/jhrrb2hQIECBQpACbgNeBH4AhgCTgHfAxPG0a66cA/wNWACz7LxMy0bKsCrOIOPAK8AC4GZQJ+WHwXeAG4fHzPjKAHvIoaeAp4BWqs4FWRr2YH+A7xwFm3MhNWIcX8A3SncDuBx4IS2ebS5ptWiDNyBbJ+dwCFkVu8FflWj7qtDr1fb/AasBT4A9gLHtPzWRhnuoxMYJPnnPanvT3LobgpoWr3pYzXcx1zcNjgMvAQsAGbhZs8AD+bQfljb/gAsB+YgjsFOjgE+BqaNaQRAGxIDDPA2MKmq/k5gWOs7cujP0LbfVJU/BLyGbF8DfEmt86gLz+GWORTIDirnvBz6k3EuOVT/rXLW5NA/gz0qMjvC2a+cthz6F2vb4QhnAW5VcuF8YBQJbKUI7z3t6IEcfXRp268inBbgL32C26scEShpvXWtIWzRd0+EE8JqffdHOKeRf6UCtIdIsYGcBP4ELiWe6N3t8etByWtzfQrX/n+n6+zjDPpJD07HlXNZDv1p2nYowulUzp6YUGxFQFYD3Kwn4Tt9X5OilQTb5kCEY1OY2GCjmIjMxO/I/gzhKeXtJT3P8tGtbQzwZIR3IfA34nhidgRRRvy7Ae4ivHqtwIDyNtShv0HbDBAPdrco7yfi3jOKl3GpQixytyEJ5BDiLtPQgqQ7o8CUCO9yZDUM8GwG3SBagc/IltnapHJFBt2Vyt2cwluqvH6yTVAUa1TsoxSeTcsPEZ/lKbgcqjfCqwC7MvAyow2XGD4W4ZWAjaS7Spv2bCS+59/BOZExr4bFEyr6YQqvHfdPhWDrg1G6ijc3i4FpccRin75HU3iHM+rVwx3MQso6ELu0NwGLgIsCPN+NXplQ75eFXG47cnnRcHQA20k+jvqoIIchW3cUCXRX6LMWF5cM8Dq1AS6pj6fJPuGJmA6s8zr/EXgE+By58vEH0gVs07IR4NOAUUbrRvR7O3Bz1UBGkOPtOiQ2GWAHcrF3bj0D6ALexwUio99Xe5wtWt5D7QXCeuXMxyWdNhbM17r1VW02I2d+gzsWACzxBmOAX4DnSTlWdyCxIjSTq5TXiqxOiPemp9ntlft52FuR9gdwM78wwDmBrFiNW74R+DkibpCz+XLEg8V4A55uj1fuH7xi10AGOT734lY+9Azirc4luEjbiOc4cI5q93nlfVrWghzYGtXfVmBCGdkyU2kcJiIrDO4843/PRu4DGoU5wLIycH8DRS3m6TtpIPNoPJaWgauaILxY30kDWdSE/m4oAxc0Qfha4Dr+6yanIjeLnU3ob3IZyUBDz+4xiC+hdkUWB7hZsJuIrWlHx2PU3veOF4aRm8lEpA3EpNSfbeQ+sxcoUKDA/wv/ArHxj/XR5l5KAAAAAElFTkSuQmCC" />
                        </span>
                        <span class="nav-link-text">Payment Individual</span>
                    </a>
                </li>
                <li class="nav-item">
                    <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                    <a class="nav-link  {{ Request::is('paymentg') ? 'active' : '' }}"
                        href="{{ route('paymentg') }}">
                        <span class="nav-icon">
                            <img width="23px"
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAAEaElEQVRoge2YXYhVVRTHf/d6m+nDMsmZnCwk6qUpzCTNmYqKkAzKmvKDAfEjCKYo9SHIHgp6CAwLeiqCinopjCCiIJjCGjAdP0jDKMpEyVLGSp0sHa1p97DWdu/uPXufc8/c6/Rw/nA4h73/+7/X/jhrrb2hQIECBQpACbgNeBH4AhgCTgHfAxPG0a66cA/wNWACz7LxMy0bKsCrOIOPAK8AC4GZQJ+WHwXeAG4fHzPjKAHvIoaeAp4BWqs4FWRr2YH+A7xwFm3MhNWIcX8A3SncDuBx4IS2ebS5ptWiDNyBbJ+dwCFkVu8FflWj7qtDr1fb/AasBT4A9gLHtPzWRhnuoxMYJPnnPanvT3LobgpoWr3pYzXcx1zcNjgMvAQsAGbhZs8AD+bQfljb/gAsB+YgjsFOjgE+BqaNaQRAGxIDDPA2MKmq/k5gWOs7cujP0LbfVJU/BLyGbF8DfEmt86gLz+GWORTIDirnvBz6k3EuOVT/rXLW5NA/gz0qMjvC2a+cthz6F2vb4QhnAW5VcuF8YBQJbKUI7z3t6IEcfXRp268inBbgL32C26scEShpvXWtIWzRd0+EE8JqffdHOKeRf6UCtIdIsYGcBP4ELiWe6N3t8etByWtzfQrX/n+n6+zjDPpJD07HlXNZDv1p2nYowulUzp6YUGxFQFYD3Kwn4Tt9X5OilQTb5kCEY1OY2GCjmIjMxO/I/gzhKeXtJT3P8tGtbQzwZIR3IfA34nhidgRRRvy7Ae4ivHqtwIDyNtShv0HbDBAPdrco7yfi3jOKl3GpQixytyEJ5BDiLtPQgqQ7o8CUCO9yZDUM8GwG3SBagc/IltnapHJFBt2Vyt2cwluqvH6yTVAUa1TsoxSeTcsPEZ/lKbgcqjfCqwC7MvAyow2XGD4W4ZWAjaS7Spv2bCS+59/BOZExr4bFEyr6YQqvHfdPhWDrg1G6ijc3i4FpccRin75HU3iHM+rVwx3MQso6ELu0NwGLgIsCPN+NXplQ75eFXG47cnnRcHQA20k+jvqoIIchW3cUCXRX6LMWF5cM8Dq1AS6pj6fJPuGJmA6s8zr/EXgE+By58vEH0gVs07IR4NOAUUbrRvR7O3Bz1UBGkOPtOiQ2GWAHcrF3bj0D6ALexwUio99Xe5wtWt5D7QXCeuXMxyWdNhbM17r1VW02I2d+gzsWACzxBmOAX4DnSTlWdyCxIjSTq5TXiqxOiPemp9ntlft52FuR9gdwM78wwDmBrFiNW74R+DkibpCz+XLEg8V4A55uj1fuH7xi10AGOT734lY+9Azirc4luEjbiOc4cI5q93nlfVrWghzYGtXfVmBCGdkyU2kcJiIrDO4843/PRu4DGoU5wLIycH8DRS3m6TtpIPNoPJaWgauaILxY30kDWdSE/m4oAxc0Qfha4Dr+6yanIjeLnU3ob3IZyUBDz+4xiC+hdkUWB7hZsJuIrWlHx2PU3veOF4aRm8lEpA3EpNSfbeQ+sxcoUKDA/wv/ArHxj/XR5l5KAAAAAElFTkSuQmCC" />
                        </span>
                        <span class="nav-link-text">Payment Group</span>
                    </a>
                </li>
                <?php  } ?>
            </ul>
        </nav>
    </div>
</div>
</header>
